# shop_accounting
 
 chmod +x download_assets.sh
./download_assets.sh