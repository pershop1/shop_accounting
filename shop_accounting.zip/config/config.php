<?php
/**
 * تنظیمات اصلی سیستم حسابداری فروشگاه
 * تاریخ آخرین بروزرسانی: ۱۴۰۲/۱۲/۲۹
 */

// جلوگیری از دسترسی مستقیم به فایل
if (!defined('BASE_PATH')) {
    define('BASE_PATH', rtrim(dirname(dirname(__FILE__)), '/'));
}

// تنظیم منطقه زمانی
date_default_timezone_set('Asia/Tehran');

// تنظیمات نشست
session_start();

// تنظیمات پایه سایت
define('SITE_TITLE', 'سیستم حسابداری فروشگاه');
define('SITE_VERSION', '1.0.0');
define('BASE_URL', 'http://localhost/shop_accounting');

// تنظیمات دیتابیس
require_once BASE_PATH . '/config/db.php';

// لود کردن توابع
require_once BASE_PATH . '/includes/functions.php';

// تنظیمات آپلود
define('UPLOAD_PATH', BASE_PATH . '/uploads');
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'gif']);

// تنظیمات محصولات
define('PRODUCTS_PER_PAGE', 20);
define('DEFAULT_PRODUCT_IMAGE', 'assets/img/no-image.png');

// تنظیمات فروش
define('INVOICE_PREFIX', 'INV');
define('TAX_RATE', 9); // درصد مالیات

// تنظیمات بروزرسانی
define('UPDATE_CHECK_ENABLED', true);
define('UPDATE_CHECK_INTERVAL', 24 * 60 * 60); // یک روز
define('UPDATE_SERVER', 'https://update.example.com');

// تعریف نقش‌های کاربری و دسترسی‌ها
define('USER_ROLES', [
    'admin' => [
        'title' => 'مدیر کل',
        'permissions' => ['all']
    ],
    'manager' => [
        'title' => 'مدیر فروش',
        'permissions' => [
            'products_view',
            'products_add',
            'products_edit',
            'sales_view',
            'sales_add',
            'reports_view'
        ]
    ],
    'accountant' => [
        'title' => 'حسابدار',
        'permissions' => [
            'products_view',
            'sales_view',
            'reports_view'
        ]
    ],
    'seller' => [
        'title' => 'فروشنده',
        'permissions' => [
            'products_view',
            'sales_add',
            'sales_view'
        ]
    ],
    'stockkeeper' => [
        'title' => 'انباردار',
        'permissions' => [
            'products_view',
            'inventory_manage'
        ]
    ]
]);

// تنظیمات پیش‌فرض کاربر اگر لاگین نکرده باشد
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 0;
    $_SESSION['user_name'] = 'مهمان';
    $_SESSION['user_role'] = '';
}

// تابع اتوماتیک برای لود کلاس‌ها
spl_autoload_register(function ($class) {
    $file = BASE_PATH . '/classes/' . str_replace('\\', '/', $class) . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

// تنظیم header های امنیتی
header('X-Frame-Options: SAMEORIGIN');
header('X-XSS-Protection: 1; mode=block');
header('X-Content-Type-Options: nosniff');

// تنظیم error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', BASE_PATH . '/logs/error.log');

// ایجاد پوشه logs اگر وجود نداشت
if (!file_exists(BASE_PATH . '/logs')) {
    mkdir(BASE_PATH . '/logs', 0777, true);
}