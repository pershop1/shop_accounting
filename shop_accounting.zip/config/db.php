<?php
/**
 * تنظیمات پایگاه داده
 * تاریخ ایجاد: ۱۴۰۲/۱۲/۲۹
 */

// تنظیمات اتصال به پایگاه داده
define('DB_HOST', 'localhost');     // آدرس سرور پایگاه داده
define('DB_NAME', 'shop_accounting');// نام پایگاه داده
define('DB_USER', 'root');          // نام کاربری پایگاه داده
define('DB_PASS', '');              // رمز عبور پایگاه داده
define('DB_CHARSET', 'utf8mb4');    // کدگذاری پایگاه داده

try {
    // ایجاد اتصال PDO
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET . " COLLATE " . DB_CHARSET . "_persian_ci"
    ];
    
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);

} catch (PDOException $e) {
    // ذخیره خطا در فایل لاگ
    error_log("خطا در اتصال به پایگاه داده: " . $e->getMessage());
    
    // نمایش پیام خطای مناسب به کاربر
    die("متأسفانه در حال حاضر امکان اتصال به پایگاه داده وجود ندارد. لطفاً بعداً تلاش کنید.");
}

/**
 * ساختار جداول پایگاه داده:
 * 
 * جدول users:
 * - id: شناسه یکتا (INT, AUTO_INCREMENT)
 * - username: نام کاربری (VARCHAR(50))
 * - password: رمز عبور (VARCHAR(255))
 * - name: نام کامل (VARCHAR(100))
 * - role: نقش کاربر (ENUM('admin', 'manager', 'accountant', 'seller', 'stockkeeper'))
 * - status: وضعیت (TINYINT(1))
 * - created_at: تاریخ ایجاد (DATETIME)
 * - last_login: آخرین ورود (DATETIME)
 * 
 * جدول categories:
 * - id: شناسه یکتا (INT, AUTO_INCREMENT)
 * - name: نام دسته‌بندی (VARCHAR(100))
 * - description: توضیحات (TEXT)
 * - parent_id: شناسه دسته‌بندی والد (INT)
 * - status: وضعیت (TINYINT(1))
 * - created_at: تاریخ ایجاد (DATETIME)
 * - created_by: ایجاد کننده (INT)
 * 
 * جدول products:
 * - id: شناسه یکتا (INT, AUTO_INCREMENT)
 * - name: نام محصول (VARCHAR(200))
 * - code: کد محصول (VARCHAR(50))
 * - barcode: بارکد (VARCHAR(50))
 * - category_id: شناسه دسته‌بندی (INT)
 * - buy_price: قیمت خرید (DECIMAL(12,0))
 * - sell_price: قیمت فروش (DECIMAL(12,0))
 * - stock: موجودی (INT)
 * - min_stock: حداقل موجودی (INT)
 * - description: توضیحات (TEXT)
 * - image: تصویر (VARCHAR(255))
 * - status: وضعیت (TINYINT(1))
 * - created_at: تاریخ ایجاد (DATETIME)
 * - created_by: ایجاد کننده (INT)
 * - updated_at: تاریخ بروزرسانی (DATETIME)
 * - updated_by: بروزرسانی کننده (INT)
 * 
 * جدول inventory_log:
 * - id: شناسه یکتا (INT, AUTO_INCREMENT)
 * - product_id: شناسه محصول (INT)
 * - type: نوع تراکنش (ENUM('in', 'out'))
 * - quantity: تعداد (INT)
 * - description: توضیحات (TEXT)
 * - reference: شماره مرجع (VARCHAR(50))
 * - created_at: تاریخ ایجاد (DATETIME)
 * - created_by: ایجاد کننده (INT)
 * 
 * جدول sales:
 * - id: شناسه یکتا (INT, AUTO_INCREMENT)
 * - invoice_number: شماره فاکتور (VARCHAR(50))
 * - customer_name: نام مشتری (VARCHAR(100))
 * - total_amount: مبلغ کل (DECIMAL(12,0))
 * - discount: تخفیف (DECIMAL(12,0))
 * - final_amount: مبلغ نهایی (DECIMAL(12,0))
 * - payment_method: روش پرداخت (ENUM('cash', 'card', 'credit'))
 * - status: وضعیت (ENUM('pending', 'completed', 'canceled'))
 * - description: توضیحات (TEXT)
 * - created_at: تاریخ ایجاد (DATETIME)
 * - created_by: ایجاد کننده (INT)
 * 
 * جدول sales_items:
 * - id: شناسه یکتا (INT, AUTO_INCREMENT)
 * - sale_id: شناسه فروش (INT)
 * - product_id: شناسه محصول (INT)
 * - quantity: تعداد (INT)
 * - price: قیمت واحد (DECIMAL(12,0))
 * - discount: تخفیف (DECIMAL(12,0))
 * - total: مبلغ کل (DECIMAL(12,0))
 */

// کوئری‌های ایجاد جداول
$tables_sql = [
    "CREATE TABLE IF NOT EXISTS `users` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `username` varchar(50) NOT NULL,
        `password` varchar(255) NOT NULL,
        `name` varchar(100) NOT NULL,
        `role` enum('admin','manager','accountant','seller','stockkeeper') NOT NULL,
        `status` tinyint(1) NOT NULL DEFAULT '1',
        `created_at` datetime NOT NULL,
        `last_login` datetime DEFAULT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `username` (`username`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;",

    "CREATE TABLE IF NOT EXISTS `categories` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `name` varchar(100) NOT NULL,
        `description` text,
        `parent_id` int(11) DEFAULT NULL,
        `status` tinyint(1) NOT NULL DEFAULT '1',
        `created_at` datetime NOT NULL,
        `created_by` int(11) NOT NULL,
        PRIMARY KEY (`id`),
        KEY `parent_id` (`parent_id`),
        KEY `created_by` (`created_by`),
        CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
        CONSTRAINT `categories_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;",

    "CREATE TABLE IF NOT EXISTS `products` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `name` varchar(200) NOT NULL,
        `code` varchar(50) NOT NULL,
        `barcode` varchar(50) DEFAULT NULL,
        `category_id` int(11) NOT NULL,
        `buy_price` decimal(12,0) NOT NULL,
        `sell_price` decimal(12,0) NOT NULL,
        `stock` int(11) NOT NULL DEFAULT '0',
        `min_stock` int(11) NOT NULL DEFAULT '0',
        `description` text,
        `image` varchar(255) DEFAULT NULL,
        `status` tinyint(1) NOT NULL DEFAULT '1',
        `created_at` datetime NOT NULL,
        `created_by` int(11) NOT NULL,
        `updated_at` datetime DEFAULT NULL,
        `updated_by` int(11) DEFAULT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `code` (`code`),
        KEY `category_id` (`category_id`),
        KEY `created_by` (`created_by`),
        KEY `updated_by` (`updated_by`),
        CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`),
        CONSTRAINT `products_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
        CONSTRAINT `products_ibfk_3` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;",

    "CREATE TABLE IF NOT EXISTS `inventory_log` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `product_id` int(11) NOT NULL,
        `type` enum('in','out') NOT NULL,
        `quantity` int(11) NOT NULL,
        `description` text,
        `reference` varchar(50) DEFAULT NULL,
        `created_at` datetime NOT NULL,
        `created_by` int(11) NOT NULL,
        PRIMARY KEY (`id`),
        KEY `product_id` (`product_id`),
        KEY `created_by` (`created_by`),
        CONSTRAINT `inventory_log_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
        CONSTRAINT `inventory_log_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;",

    "CREATE TABLE IF NOT EXISTS `sales` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `invoice_number` varchar(50) NOT NULL,
        `customer_name` varchar(100) DEFAULT NULL,
        `total_amount` decimal(12,0) NOT NULL,
        `discount` decimal(12,0) NOT NULL DEFAULT '0',
        `final_amount` decimal(12,0) NOT NULL,
        `payment_method` enum('cash','card','credit') NOT NULL,
        `status` enum('pending','completed','canceled') NOT NULL DEFAULT 'pending',
        `description` text,
        `created_at` datetime NOT NULL,
        `created_by` int(11) NOT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `invoice_number` (`invoice_number`),
        KEY `created_by` (`created_by`),
        CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;",

    "CREATE TABLE IF NOT EXISTS `sales_items` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `sale_id` int(11) NOT NULL,
        `product_id` int(11) NOT NULL,
        `quantity` int(11) NOT NULL,
        `price` decimal(12,0) NOT NULL,
        `discount` decimal(12,0) NOT NULL DEFAULT '0',
        `total` decimal(12,0) NOT NULL,
        PRIMARY KEY (`id`),
        KEY `sale_id` (`sale_id`),
        KEY `product_id` (`product_id`),
        CONSTRAINT `sales_items_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`),
        CONSTRAINT `sales_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;"
];

// ایجاد جداول اگر وجود نداشته باشند
foreach ($tables_sql as $sql) {
    try {
        $pdo->exec($sql);
    } catch (PDOException $e) {
        error_log("خطا در ایجاد جدول: " . $e->getMessage());
    }
}