<?php
/**
 * داشبورد مدیریت سیستم حسابداری فروشگاه
 * تاریخ ایجاد: ۱۴۰۲/۱۲/۲۹
 */

// بارگذاری تنظیمات
require_once 'config/config.php';

// بررسی ورود کاربر
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// تنظیم عنوان صفحه و صفحه فعال
$page_title = 'داشبورد';
$current_page = 'dashboard';

// دریافت آمار فروش هفتگی با مدیریت خطاها
$weekly_sales = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $sale = db_get_row(
        'sales',
        ['DATE(created_at)' => $date, 'status' => 'completed'],
        'COALESCE(SUM(final_amount), 0) as total'
    );
    // اگر نتیجه‌ای نبود، مقدار 0 را اضافه کن
    $weekly_sales[] = isset($sale['total']) ? (int)$sale['total'] : 0;
}

// دریافت آمار با مدیریت خطا
$stats = get_dashboard_stats();
if (!is_array($stats)) {
    $stats = [
        'total_products' => 0,
        'low_stock' => 0,
        'out_of_stock' => 0,
        'today_sales_count' => 0,
        'today_sales_amount' => 0
    ];
}

// دریافت آخرین فروش‌ها
$latest_sales = db_get_rows(
    'sales',
    ['status' => 'completed'],
    '*',
    'created_at DESC',
    '5'
);

// دریافت محصولات کم موجود
$low_stock_products = db_get_rows(
    'products',
    ['stock <= min_stock', 'stock > 0', 'status' => 1],
    '*',
    'stock ASC',
    '5'
);

?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> - سیستم حسابداری فروشگاه</title>
    <link rel="stylesheet" href="assets/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php require_once 'includes/header.php'; ?>

    <div class="container py-4">
        <div class="row">
            <div class="col-lg-3">
                <?php require_once 'includes/sidebar.php'; ?>
            </div>
            <div class="col-lg-9">
                <!-- کارت‌های آمار -->
                <div class="row g-3">
                    <!-- کارت تعداد محصولات -->
                    <div class="col-md-6 col-lg-3">
                        <div class="card bg-primary text-white h-100">
                            <div class="card-body">
                                <h5 class="card-title">کل محصولات</h5>
                                <p class="card-text display-6">
                                    <?php echo number_format($stats['total_products']); ?>
                                </p>
                                <small>تعداد کل محصولات ثبت شده</small>
                            </div>
                        </div>
                    </div>

                    <!-- کارت محصولات کم موجود -->
                    <div class="col-md-6 col-lg-3">
                        <div class="card bg-warning text-dark h-100">
                            <div class="card-body">
                                <h5 class="card-title">کم موجود</h5>
                                <p class="card-text display-6">
                                    <?php echo number_format($stats['low_stock']); ?>
                                </p>
                                <small>محصولات با موجودی کم</small>
                            </div>
                        </div>
                    </div>

                    <!-- کارت محصولات ناموجود -->
                    <div class="col-md-6 col-lg-3">
                        <div class="card bg-danger text-white h-100">
                            <div class="card-body">
                                <h5 class="card-title">ناموجود</h5>
                                <p class="card-text display-6">
                                    <?php echo number_format($stats['out_of_stock']); ?>
                                </p>
                                <small>محصولات ناموجود</small>
                            </div>
                        </div>
                    </div>

                    <!-- کارت فروش امروز -->
                    <div class="col-md-6 col-lg-3">
                        <div class="card bg-success text-white h-100">
                            <div class="card-body">
                                <h5 class="card-title">فروش امروز</h5>
                                <p class="card-text display-6">
                                    <?php echo number_format($stats['today_sales_count']); ?>
                                </p>
                                <small>
                                    مبلغ: <?php echo number_format($stats['today_sales_amount']); ?> تومان
                                </small>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- نمودار فروش هفتگی -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h5 class="card-title mb-0">نمودار فروش هفتگی</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="salesChart" height="300"></canvas>
                    </div>
                </div>

                <!-- آخرین فروش‌ها -->
                <div class="card mt-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0">آخرین فروش‌ها</h5>
                        <a href="modules/sales/list.php" class="btn btn-sm btn-primary">مشاهده همه</a>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>شماره فاکتور</th>
                                        <th>مشتری</th>
                                        <th>مبلغ</th>
                                        <th>تاریخ</th>
                                        <th>وضعیت</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($latest_sales)): ?>
                                    <tr>
                                        <td colspan="5" class="text-center">فروشی ثبت نشده است</td>
                                    </tr>
                                    <?php else: ?>
                                        <?php foreach ($latest_sales as $sale): ?>
                                        <tr>
                                            <td>
                                                <a href="modules/sales/view.php?id=<?php echo $sale['id']; ?>">
                                                    <?php echo htmlspecialchars($sale['invoice_number']); ?>
                                                </a>
                                            </td>
                                            <td><?php echo htmlspecialchars($sale['customer_name'] ?: 'فروش متفرقه'); ?></td>
                                            <td><?php echo number_format($sale['final_amount']); ?> تومان</td>
                                            <td><?php echo $sale['created_at']; ?></td>
                                            <td>
                                                <span class="badge bg-success">تکمیل شده</span>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- محصولات کم موجود -->
                <div class="card mt-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0">محصولات کم موجود</h5>
                        <a href="modules/products/inventory.php" class="btn btn-sm btn-primary">مدیریت موجودی</a>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>نام محصول</th>
                                        <th>کد</th>
                                        <th>موجودی فعلی</th>
                                        <th>حداقل موجودی</th>
                                        <th>عملیات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($low_stock_products)): ?>
                                    <tr>
                                        <td colspan="5" class="text-center">محصول کم موجودی وجود ندارد</td>
                                    </tr>
                                    <?php else: ?>
                                        <?php foreach ($low_stock_products as $product): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($product['name']); ?></td>
                                            <td><?php echo htmlspecialchars($product['code']); ?></td>
                                            <td>
                                                <span class="badge bg-warning">
                                                    <?php echo $product['stock']; ?>
                                                </span>
                                            </td>
                                            <td><?php echo $product['min_stock']; ?></td>
                                            <td>
                                                <a href="modules/products/inventory.php?id=<?php echo $product['id']; ?>" 
                                                   class="btn btn-sm btn-info">
                                                    افزایش موجودی
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php require_once 'includes/footer.php'; ?>

    <!-- اسکریپت‌های مورد نیاز -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // نمودار فروش هفتگی
        const salesData = <?php echo json_encode($weekly_sales); ?>;
        const ctx = document.getElementById('salesChart').getContext('2d');
        
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه'],
                datasets: [{
                    label: 'فروش روزانه (تومان)',
                    data: salesData,
                    borderColor: 'rgb(75, 192, 192)',
                    tension: 0.1,
                    fill: false
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return new Intl.NumberFormat('fa-IR').format(value) + ' تومان';
                            }
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>