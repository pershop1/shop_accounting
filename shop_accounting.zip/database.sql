-- ایجاد دیتابیس با پشتیبانی از کاراکترهای فارسی
CREATE DATABASE IF NOT EXISTS shop_accounting
CHARACTER SET utf8mb4 
COLLATE utf8mb4_persian_ci;

USE shop_accounting;

-- جدول دسته‌بندی محصولات
CREATE TABLE categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    parent_id INT DEFAULT NULL,
    category_name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- جدول محصولات
CREATE TABLE products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(200) NOT NULL,
    product_code VARCHAR(50) NOT NULL UNIQUE,
    category_id INT,
    subcategory_id INT,
    brand VARCHAR(100),
    unit VARCHAR(50) NOT NULL,
    purchase_price DECIMAL(15,0) NOT NULL DEFAULT 0,
    sale_price DECIMAL(15,0) NOT NULL DEFAULT 0,
    initial_stock INT NOT NULL DEFAULT 0,
    current_stock INT NOT NULL DEFAULT 0,
    min_stock INT NOT NULL DEFAULT 0,
    reorder_point INT NOT NULL DEFAULT 0,
    description TEXT,
    specifications TEXT,
    barcode VARCHAR(100),
    weight INT,
    dimensions VARCHAR(50),
    storage_location VARCHAR(100),
    tags VARCHAR(255),
    main_image VARCHAR(255),
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
    FOREIGN KEY (subcategory_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- جدول تصاویر گالری محصولات
CREATE TABLE product_images (
    id INT PRIMARY KEY AUTO_INCREMENT,
    product_id INT NOT NULL,
    image_path VARCHAR(255) NOT NULL,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- جدول انبار و موجودی
CREATE TABLE inventory_transactions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    product_id INT NOT NULL,
    transaction_type ENUM('IN', 'OUT') NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(15,0) NOT NULL DEFAULT 0,
    reference_type VARCHAR(50) NOT NULL COMMENT 'نوع تراکنش: PURCHASE, SALE, ADJUSTMENT',
    reference_id INT COMMENT 'شناسه مرجع (مثلاً شماره فاکتور)',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT COMMENT 'شناسه کاربر ثبت کننده',
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- جدول فاکتورهای فروش
CREATE TABLE sales_invoices (
    id INT PRIMARY KEY AUTO_INCREMENT,
    invoice_number VARCHAR(50) NOT NULL UNIQUE,
    customer_name VARCHAR(200),
    customer_phone VARCHAR(20),
    total_amount DECIMAL(15,0) NOT NULL DEFAULT 0 COMMENT 'مبلغ کل',
    discount_amount DECIMAL(15,0) NOT NULL DEFAULT 0 COMMENT 'مبلغ تخفیف',
    tax_amount DECIMAL(15,0) NOT NULL DEFAULT 0 COMMENT 'مبلغ مالیات',
    final_amount DECIMAL(15,0) NOT NULL DEFAULT 0 COMMENT 'مبلغ نهایی',
    payment_status ENUM('PAID', 'UNPAID', 'PARTIAL') DEFAULT 'UNPAID',
    payment_method VARCHAR(50),
    payment_reference VARCHAR(100) COMMENT 'شماره پیگیری پرداخت',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT COMMENT 'شناسه کاربر ثبت کننده',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- جدول اقلام فاکتور
CREATE TABLE invoice_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    invoice_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    unit_price DECIMAL(15,0) NOT NULL DEFAULT 0,
    discount_amount DECIMAL(15,0) NOT NULL DEFAULT 0,
    tax_amount DECIMAL(15,0) NOT NULL DEFAULT 0,
    total_amount DECIMAL(15,0) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (invoice_id) REFERENCES sales_invoices(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- جدول تنظیمات سیستم
CREATE TABLE settings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT,
    setting_group VARCHAR(50) NOT NULL DEFAULT 'general',
    is_system TINYINT(1) DEFAULT 0 COMMENT 'آیا تنظیم سیستمی است',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- جدول لاگ‌های سیستم
CREATE TABLE system_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    log_type VARCHAR(50) NOT NULL,
    log_message TEXT NOT NULL,
    log_details TEXT,
    ip_address VARCHAR(45),
    user_agent VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by INT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_persian_ci;

-- ایجاد ایندکس‌های مورد نیاز
CREATE INDEX idx_products_code ON products(product_code);
CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_products_subcategory ON products(subcategory_id);
CREATE INDEX idx_products_active ON products(is_active);
CREATE INDEX idx_invoices_number ON sales_invoices(invoice_number);
CREATE INDEX idx_invoices_date ON sales_invoices(created_at);
CREATE INDEX idx_inventory_product ON inventory_transactions(product_id);
CREATE INDEX idx_inventory_date ON inventory_transactions(created_at);
CREATE INDEX idx_settings_key ON settings(setting_key);
CREATE INDEX idx_logs_type ON system_logs(log_type);
CREATE INDEX idx_logs_date ON system_logs(created_at);

-- درج داده‌های اولیه برای تنظیمات سیستم
INSERT INTO settings (setting_key, setting_value, setting_group, is_system) VALUES
('site_name', 'سیستم حسابداری فروشگاه', 'general', 1),
('tax_rate', '9', 'financial', 1),
('invoice_prefix', 'INV-', 'invoice', 1),
('products_per_page', '20', 'display', 1),
('enable_stock_alerts', '1', 'inventory', 1),
('low_stock_threshold', '10', 'inventory', 1),
('default_payment_method', 'CASH', 'financial', 1),
('enable_product_images', '1', 'products', 1),
('backup_enabled', '1', 'system', 1),
('last_update_check', '', 'system', 1);

-- درج دسته‌بندی‌های پیش‌فرض
INSERT INTO categories (category_name, description) VALUES
('عمومی', 'دسته‌بندی پیش‌فرض برای محصولات'),
('متفرقه', 'سایر محصولات');