<?php
/**
 * توابع عمومی سیستم حسابداری فروشگاه
 * تاریخ آخرین بروزرسانی: ۲۹ اسفند ۱۴۰۲
 */

// جلوگیری از دسترسی مستقیم
if (!defined('BASE_PATH')) {
    exit('دسترسی مستقیم به این فایل امکان‌پذیر نیست');
}

/**
 * دریافت یک رکورد از دیتابیس با مدیریت خطا
 */
function db_get_row($table, $where = [], $fields = '*') {
    global $pdo;
    
    try {
        $sql = "SELECT $fields FROM `$table`";
        $params = [];
        
        if (!empty($where)) {
            $sql .= " WHERE ";
            $conditions = [];
            foreach ($where as $key => $value) {
                if (is_numeric($key)) {
                    $conditions[] = $value; // برای شرط‌های پیچیده
                } else {
                    $conditions[] = "`$key` = ?";
                    $params[] = $value;
                }
            }
            $sql .= implode(" AND ", $conditions);
        }
        
        $stmt = $pdo->prepare($sql);
        if (!$stmt->execute($params)) {
            error_log("خطا در اجرای کوئری: " . implode(", ", $stmt->errorInfo()));
            return [];
        }
        
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result !== false ? $result : [];
        
    } catch (PDOException $e) {
        error_log("خطا در دیتابیس: " . $e->getMessage());
        return [];
    }
}

/**
 * دریافت چند رکورد از دیتابیس با مدیریت خطا
 */
function db_get_rows($table, $where = [], $fields = '*', $order = '', $limit = '') {
    global $pdo;
    
    try {
        $sql = "SELECT $fields FROM `$table`";
        $params = [];
        
        if (!empty($where)) {
            $sql .= " WHERE ";
            $conditions = [];
            foreach ($where as $key => $value) {
                if (is_numeric($key)) {
                    $conditions[] = $value;
                } else {
                    $conditions[] = "`$key` = ?";
                    $params[] = $value;
                }
            }
            $sql .= implode(" AND ", $conditions);
        }
        
        if ($order) {
            $sql .= " ORDER BY $order";
        }
        
        if ($limit) {
            $sql .= " LIMIT $limit";
        }
        
        $stmt = $pdo->prepare($sql);
        if (!$stmt->execute($params)) {
            error_log("خطا در اجرای کوئری: " . implode(", ", $stmt->errorInfo()));
            return [];
        }
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
        
    } catch (PDOException $e) {
        error_log("خطا در دیتابیس: " . $e->getMessage());
        return [];
    }
}

/**
 * درج رکورد در دیتابیس
 */
function db_insert($table, $data) {
    global $pdo;
    
    try {
        $fields = array_keys($data);
        $values = array_fill(0, count($fields), '?');
        
        $sql = "INSERT INTO `$table` (`" . implode('`, `', $fields) . "`) 
                VALUES (" . implode(', ', $values) . ")";
        
        $stmt = $pdo->prepare($sql);
        if (!$stmt->execute(array_values($data))) {
            error_log("خطا در درج اطلاعات: " . implode(", ", $stmt->errorInfo()));
            return false;
        }
        
        return $pdo->lastInsertId();
        
    } catch (PDOException $e) {
        error_log("خطا در دیتابیس: " . $e->getMessage());
        return false;
    }
}

/**
 * بروزرسانی رکورد در دیتابیس
 */
function db_update($table, $data, $where) {
    global $pdo;
    
    try {
        $set = [];
        $params = [];
        
        foreach ($data as $key => $value) {
            $set[] = "`$key` = ?";
            $params[] = $value;
        }
        
        $conditions = [];
        foreach ($where as $key => $value) {
            $conditions[] = "`$key` = ?";
            $params[] = $value;
        }
        
        $sql = "UPDATE `$table` SET " . implode(', ', $set) . 
               " WHERE " . implode(' AND ', $conditions);
        
        $stmt = $pdo->prepare($sql);
        return $stmt->execute($params);
        
    } catch (PDOException $e) {
        error_log("خطا در دیتابیس: " . $e->getMessage());
        return false;
    }
}

/**
 * حذف رکورد از دیتابیس
 */
function db_delete($table, $where) {
    global $pdo;
    
    try {
        $conditions = [];
        $params = [];
        
        foreach ($where as $key => $value) {
            $conditions[] = "`$key` = ?";
            $params[] = $value;
        }
        
        $sql = "DELETE FROM `$table` WHERE " . implode(' AND ', $conditions);
        
        $stmt = $pdo->prepare($sql);
        return $stmt->execute($params);
        
    } catch (PDOException $e) {
        error_log("خطا در دیتابیس: " . $e->getMessage());
        return false;
    }
}

/**
 * محاسبه آمار داشبورد
 */
function get_dashboard_stats() {
    try {
        // تعداد کل محصولات
        $products = db_get_row('products', [], 'COUNT(*) as total');
        $total_products = isset($products['total']) ? (int)$products['total'] : 0;
        
        // تعداد محصولات کم موجود
        $low_stock = db_get_row(
            'products', 
            ['stock <= min_stock', 'stock > 0', 'status' => 1], 
            'COUNT(*) as total'
        );
        $low_stock_count = isset($low_stock['total']) ? (int)$low_stock['total'] : 0;
        
        // تعداد محصولات ناموجود
        $out_of_stock = db_get_row(
            'products',
            ['stock' => 0],
            'COUNT(*) as total'
        );
        $out_of_stock_count = isset($out_of_stock['total']) ? (int)$out_of_stock['total'] : 0;
        
        // فروش امروز
        $today_sales = db_get_row(
            'sales',
            ['DATE(created_at)' => date('Y-m-d'), 'status' => 'completed'],
            'COUNT(*) as count, COALESCE(SUM(final_amount), 0) as total'
        );
        
        return [
            'total_products' => $total_products,
            'low_stock' => $low_stock_count,
            'out_of_stock' => $out_of_stock_count,
            'today_sales_count' => isset($today_sales['count']) ? (int)$today_sales['count'] : 0,
            'today_sales_amount' => isset($today_sales['total']) ? (float)$today_sales['total'] : 0
        ];
        
    } catch (Exception $e) {
        error_log("خطا در محاسبه آمار داشبورد: " . $e->getMessage());
        return [
            'total_products' => 0,
            'low_stock' => 0,
            'out_of_stock' => 0,
            'today_sales_count' => 0,
            'today_sales_amount' => 0
        ];
    }
}

/**
 * تبدیل تاریخ میلادی به شمسی
 */
function gregorian_to_jalali($date) {
    if (empty($date)) return '';
    
    try {
        if (is_numeric($date)) {
            $timestamp = $date;
        } else {
            $timestamp = strtotime($date);
            if ($timestamp === false) return '';
        }
        
        $datetime = new DateTime("@$timestamp");
        $datetime->setTimezone(new DateTimeZone('Asia/Tehran'));
        return $datetime->format('Y/m/d H:i');
        
    } catch (Exception $e) {
        error_log("خطا در تبدیل تاریخ: " . $e->getMessage());
        return '';
    }
}

/**
 * فرمت کردن قیمت
 */
function format_price($price) {
    if (!is_numeric($price)) return '۰ تومان';
    return number_format((float)$price, 0, '.', ',') . ' تومان';
}

/**
 * ایجاد شماره فاکتور منحصر به فرد
 */
function generate_invoice_number() {
    do {
        $number = 'INV-' . date('Ymd') . '-' . rand(1000, 9999);
        $exists = db_get_row('sales', ['invoice_number' => $number]);
    } while (!empty($exists));
    
    return $number;
}

/**
 * بررسی دسترسی کاربر
 */
function check_permission($permission) {
    // اگر کاربر لاگین نکرده باشد
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role'])) {
        return false;
    }
    
    // اگر نقش کاربر تعریف نشده باشد
    if (!isset(USER_ROLES[$_SESSION['user_role']])) {
        return false;
    }
    
    $role = $_SESSION['user_role'];
    $permissions = USER_ROLES[$role]['permissions'];
    
    // اگر دسترسی کامل داشته باشد
    if (in_array('all', $permissions)) {
        return true;
    }
    
    return in_array($permission, $permissions);
}

/**
 * بررسی وجود بروزرسانی جدید
 */
function check_updates() {
    // اگر بررسی بروزرسانی غیرفعال باشد
    if (!UPDATE_CHECK_ENABLED) {
        return false;
    }

    try {
        // بررسی زمان آخرین چک
        $last_check = $_SESSION['update_last_check'] ?? 0;
        if (time() - $last_check < UPDATE_CHECK_INTERVAL) {
            return $_SESSION['update_available'] ?? false;
        }

        // ذخیره زمان بررسی
        $_SESSION['update_last_check'] = time();
        $_SESSION['update_available'] = false;

        // بررسی نسخه فعلی
        $current_version = defined('SITE_VERSION') ? SITE_VERSION : '1.0.0';
        
        // اگر CURL نصب نباشد
        if (!function_exists('curl_init')) {
            error_log("CURL برای بررسی بروزرسانی نصب نشده است");
            return false;
        }

        $ch = curl_init(UPDATE_SERVER . '/version.json');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        // اگر دریافت اطلاعات موفق نبود
        if ($http_code !== 200 || empty($response)) {
            error_log("خطا در دریافت اطلاعات بروزرسانی. کد خطا: " . $http_code);
            return false;
        }

        // تبدیل پاسخ به آرایه
        $latest = json_decode($response, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log("خطا در پردازش پاسخ سرور بروزرسانی");
            return false;
        }

        // مقایسه نسخه‌ها
        $_SESSION['update_available'] = isset($latest['version']) && 
                                      version_compare($current_version, $latest['version'], '<');
        
        return $_SESSION['update_available'];

    } catch (Exception $e) {
        error_log("خطا در بررسی بروزرسانی: " . $e->getMessage());
        return false;
    }
}