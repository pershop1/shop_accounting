<?php
/**
 * منوی کناری برنامه حسابداری فروشگاه
 * تاریخ: ۲۹ اسفند ۱۴۰۲
 */

if (!defined('BASE_PATH')) {
    exit('دسترسی مستقیم به این فایل امکان‌پذیر نیست');
}

// تعیین صفحه فعال
$current_page = $current_page ?? '';
?>

<div class="card">
    <div class="card-body p-0">
        <div class="list-group list-group-flush">
            <!-- داشبورد -->
            <a href="<?php echo BASE_URL; ?>/dashboard.php" 
               class="list-group-item list-group-item-action <?php echo $current_page == 'dashboard' ? 'active' : ''; ?>">
                <i class="bi bi-speedometer2 ms-2"></i>
                داشبورد
            </a>

            <!-- محصولات -->
            <div class="list-group-item list-group-item-action <?php echo $current_page == 'products' ? 'active' : ''; ?>">
                <div class="d-flex align-items-center" data-bs-toggle="collapse" data-bs-target="#productsCollapse">
                    <i class="bi bi-box ms-2"></i>
                    محصولات
                    <i class="bi bi-chevron-down me-auto"></i>
                </div>
                <div class="collapse <?php echo $current_page == 'products' ? 'show' : ''; ?>" id="productsCollapse">
                    <div class="list-group list-group-flush mt-2">
                        <a href="<?php echo BASE_URL; ?>/modules/products/add.php" 
                           class="list-group-item list-group-item-action">
                            <i class="bi bi-plus-lg ms-2"></i>
                            افزودن محصول
                        </a>
                        <a href="<?php echo BASE_URL; ?>/modules/products/list.php" 
                           class="list-group-item list-group-item-action">
                            <i class="bi bi-list ms-2"></i>
                            لیست محصولات
                        </a>
                        <a href="<?php echo BASE_URL; ?>/modules/products/inventory.php" 
                           class="list-group-item list-group-item-action">
                            <i class="bi bi-box-seam ms-2"></i>
                            انبارداری
                        </a>
                    </div>
                </div>
            </div>

            <!-- فروش -->
            <div class="list-group-item list-group-item-action <?php echo $current_page == 'sales' ? 'active' : ''; ?>">
                <div class="d-flex align-items-center" data-bs-toggle="collapse" data-bs-target="#salesCollapse">
                    <i class="bi bi-cart ms-2"></i>
                    فروش
                    <i class="bi bi-chevron-down me-auto"></i>
                </div>
                <div class="collapse <?php echo $current_page == 'sales' ? 'show' : ''; ?>" id="salesCollapse">
                    <div class="list-group list-group-flush mt-2">
                        <a href="<?php echo BASE_URL; ?>/modules/sales/quick.php" 
                           class="list-group-item list-group-item-action">
                            <i class="bi bi-lightning ms-2"></i>
                            فروش سریع
                        </a>
                        <a href="<?php echo BASE_URL; ?>/modules/sales/invoice.php" 
                           class="list-group-item list-group-item-action">
                            <i class="bi bi-receipt ms-2"></i>
                            فاکتور فروش
                        </a>
                        <a href="<?php echo BASE_URL; ?>/modules/sales/list.php" 
                           class="list-group-item list-group-item-action">
                            <i class="bi bi-list-ul ms-2"></i>
                            لیست فروش‌ها
                        </a>
                    </div>
                </div>
            </div>

            <!-- گزارشات -->
            <div class="list-group-item list-group-item-action <?php echo $current_page == 'reports' ? 'active' : ''; ?>">
                <div class="d-flex align-items-center" data-bs-toggle="collapse" data-bs-target="#reportsCollapse">
                    <i class="bi bi-graph-up ms-2"></i>
                    گزارشات
                    <i class="bi bi-chevron-down me-auto"></i>
                </div>
                <div class="collapse <?php echo $current_page == 'reports' ? 'show' : ''; ?>" id="reportsCollapse">
                    <div class="list-group list-group-flush mt-2">
                        <a href="<?php echo BASE_URL; ?>/modules/reports/sales.php" 
                           class="list-group-item list-group-item-action">
                            <i class="bi bi-bar-chart ms-2"></i>
                            گزارش فروش
                        </a>
                        <a href="<?php echo BASE_URL; ?>/modules/reports/inventory.php" 
                           class="list-group-item list-group-item-action">
                            <i class="bi bi-box-seam ms-2"></i>
                            گزارش موجودی
                        </a>
                        <a href="<?php echo BASE_URL; ?>/modules/reports/profit.php" 
                           class="list-group-item list-group-item-action">
                            <i class="bi bi-currency-dollar ms-2"></i>
                            گزارش سود و زیان
                        </a>
                    </div>
                </div>
            </div>

            <?php if (check_permission('settings')): ?>
            <!-- تنظیمات -->
            <a href="<?php echo BASE_URL; ?>/settings.php" 
               class="list-group-item list-group-item-action <?php echo $current_page == 'settings' ? 'active' : ''; ?>">
                <i class="bi bi-gear ms-2"></i>
                تنظیمات
            </a>
            <?php endif; ?>
            
            <!-- بروزرسانی -->
            <a href="<?php echo BASE_URL; ?>/update.php" 
               class="list-group-item list-group-item-action <?php echo $current_page == 'update' ? 'active' : ''; ?>">
                <i class="bi bi-cloud-arrow-up ms-2"></i>
                بروزرسانی
                <?php if (check_updates()): ?>
                    <span class="badge bg-danger rounded-pill">جدید</span>
                <?php endif; ?>
            </a>
        </div>
    </div>
</div>