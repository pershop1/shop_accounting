<?php
require_once 'config/config.php';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>سیستم حسابداری هوشمند</title>
    <link rel="stylesheet" href="assets/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="assets/css/landing.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
</head>
<body>
    <!-- منوی اصلی -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white fixed-top shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="#">
                <img src="assets/images/logo.png" alt="لوگو" height="40">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#features">امکانات</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#pricing">تعرفه‌ها</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact">تماس با ما</a>
                    </li>
                </ul>
                <div class="d-flex">
                    <a href="login.php" class="btn btn-outline-primary ms-2">ورود</a>
                    <a href="register.php" class="btn btn-primary">ثبت‌نام</a>
                </div>
            </div>
        </div>
    </nav>

    <!-- بخش هدر -->
    <header class="hero-section">
        <div class="container">
            <div class="row align-items-center min-vh-100">
                <div class="col-lg-6">
                    <h1 class="display-4 fw-bold mb-4">سیستم حسابداری هوشمند</h1>
                    <p class="lead mb-4">
                        مدیریت حرفه‌ای کسب و کار خود را با سیستم حسابداری ما تجربه کنید.
                        سریع، آسان و مطمئن.
                    </p>
                    <a href="register.php" class="btn btn-primary btn-lg">
                        شروع رایگان
                        <i class="bi bi-arrow-left ms-2"></i>
                    </a>
                </div>
                <div class="col-lg-6">
                    <img src="assets/images/hero-image.png" alt="تصویر هدر" class="img-fluid">
                </div>
            </div>
        </div>
    </header>

    <!-- بخش امکانات -->
    <section id="features" class="py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">امکانات سیستم</h2>
                <p class="text-muted">ویژگی‌های منحصر به فرد سیستم حسابداری ما</p>
            </div>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center">
                            <i class="bi bi-box-seam feature-icon"></i>
                            <h5 class="card-title mt-3">مدیریت محصولات</h5>
                            <p class="card-text text-muted">
                                افزودن، ویرایش و مدیریت انواع محصولات با جزئیات کامل
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center">
                            <i class="bi bi-shop feature-icon"></i>
                            <h5 class="card-title mt-3">انبارداری هوشمند</h5>
                            <p class="card-text text-muted">
                                کنترل موجودی و مدیریت ورود و خروج کالا به صورت خودکار
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center">
                            <i class="bi bi-receipt feature-icon"></i>
                            <h5 class="card-title mt-3">فاکتور فروش</h5>
                            <p class="card-text text-muted">
                                صدور فاکتور حرفه‌ای و فروش سریع با چند کلیک
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- بخش نقشه -->
    <section id="contact" class="py-5 bg-light">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h3 class="mb-4">تماس با ما</h3>
                    <p>
                        <i class="bi bi-geo-alt me-2"></i>
                        آدرس: تهران، خیابان ولیعصر، ...
                    </p>
                    <p>
                        <i class="bi bi-telephone me-2"></i>
                        تلفن: ۰۲۱-۱۲۳۴۵۶۷۸
                    </p>
                    <p>
                        <i class="bi bi-envelope me-2"></i>
                        ایمیل: info@example.com
                    </p>
                </div>
                <div class="col-md-6">
                    <div class="map-container">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d207371.97165570173!2d51.21671975!3d35.69939135!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3f8e00491ff3dcd9%3A0xf0b3697c567024bc!2sTehran%2C+Tehran+Province%2C+Iran!5e0!3m2!1sen!2s!4v1435678901234!5m2!1sen!2s"
                            width="100%" 
                            height="300" 
                            style="border:0;" 
                            allowfullscreen="" 
                            loading="lazy">
                        </iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- فوتر -->
    <footer class="bg-dark text-light py-4">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p>© ۱۴۰۲ تمامی حقوق محفوظ است.</p>
                </div>
                <div class="col-md-6 text-end">
                    <a href="#" class="text-light me-3"><i class="bi bi-instagram"></i></a>
                    <a href="#" class="text-light me-3"><i class="bi bi-telegram"></i></a>
                    <a href="#" class="text-light"><i class="bi bi-whatsapp"></i></a>
                </div>
            </div>
        </div>
    </footer>

    <script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>