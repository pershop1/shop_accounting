<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$step = $_GET['step'] ?? 1;
$error = null;
$success = null;

function testDbConnection($host, $name, $user, $pass) {
    try {
        $pdo = new PDO(
            "mysql:host=$host;charset=utf8mb4",
            $user,
            $pass,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
        );
        return true;
    } catch (PDOException $e) {
        return false;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($step == 1) {
        $db_host = $_POST['db_host'] ?? 'localhost';
        $db_name = $_POST['db_name'] ?? 'shop_accounting';
        $db_user = $_POST['db_user'] ?? 'root';
        $db_pass = $_POST['db_pass'] ?? '';

        if (testDbConnection($db_host, $db_name, $db_user, $db_pass)) {
            // ذخیره اطلاعات در فایل config
            $config = "<?php
define('DB_HOST', '$db_host');
define('DB_NAME', '$db_name');
define('DB_USER', '$db_user');
define('DB_PASS', '$db_pass');
";
            if (file_put_contents('config/db.php', $config)) {
                $success = 'اطلاعات دیتابیس با موفقیت ذخیره شد.';
                header('Location: install.php?step=2');
                exit;
            } else {
                $error = 'خطا در ذخیره فایل تنظیمات.';
            }
        } else {
            $error = 'خطا در اتصال به دیتابیس. لطفاً اطلاعات را بررسی کنید.';
        }
    }
    
    if ($step == 2) {
        try {
            require_once 'config/db.php';
            $pdo = new PDO(
                "mysql:host=" . DB_HOST . ";charset=utf8mb4",
                DB_USER,
                DB_PASS,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );
            
            // اجرای اسکریپت ساخت دیتابیس
            $sql = file_get_contents('database/schema.sql');
            $pdo->exec($sql);
            
            $success = 'دیتابیس با موفقیت نصب شد.';
            header('Location: install.php?step=3');
            exit;
        } catch (PDOException $e) {
            $error = 'خطا در نصب دیتابیس: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نصب سیستم حسابداری فروشگاه</title>
    <link rel="stylesheet" href="assets/css/bootstrap.rtl.min.css">
    <style>
        body { padding-top: 40px; }
    </style>
</head>
<body class="bg-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header">
                        <h4 class="mb-0">نصب سیستم حسابداری فروشگاه</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>
                        
                        <?php if ($success): ?>
                            <div class="alert alert-success"><?php echo $success; ?></div>
                        <?php endif; ?>

                        <?php if ($step == 1): ?>
                            <form method="post" class="needs-validation" novalidate>
                                <div class="mb-3">
                                    <label for="db_host">آدرس هاست دیتابیس:</label>
                                    <input type="text" class="form-control" id="db_host" name="db_host" value="localhost" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="db_name">نام دیتابیس:</label>
                                    <input type="text" class="form-control" id="db_name" name="db_name" value="shop_accounting" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="db_user">نام کاربری دیتابیس:</label>
                                    <input type="text" class="form-control" id="db_user" name="db_user" value="root" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="db_pass">رمز عبور دیتابیس:</label>
                                    <input type="password" class="form-control" id="db_pass" name="db_pass">
                                </div>
                                
                                <button type="submit" class="btn btn-primary">ذخیره اطلاعات دیتابیس</button>
                            </form>

                        <?php elseif ($step == 2): ?>
                            <p>در حال نصب دیتابیس...</p>
                            <form method="post">
                                <button type="submit" class="btn btn-primary">شروع نصب دیتابیس</button>
                            </form>

                        <?php elseif ($step == 3): ?>
                            <div class="alert alert-success">
                                <h4>تبریک!</h4>
                                <p>نصب سیستم با موفقیت انجام شد.</p>
                                <p>نام کاربری مدیر: admin</p>
                                <p>رمز عبور: admin123</p>
                            </div>
                            <a href="login.php" class="btn btn-primary">ورود به سیستم</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>