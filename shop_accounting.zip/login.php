<?php
/**
 * صفحه ورود به سیستم
 */
require_once 'init.php';

// بررسی لاگین بودن کاربر
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    try {
        if (empty($username) || empty($password)) {
            throw new Exception('لطفاً نام کاربری و رمز عبور را وارد کنید.');
        }

        $user = db_get_row("SELECT * FROM users WHERE username = ?", [$username]);
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['full_name'] = $user['full_name'];
            $_SESSION['is_admin'] = $user['is_admin'];
            
            db_query("UPDATE users SET last_login = NOW() WHERE id = ?", [$user['id']]);
            
            log_action('login', 'ورود موفق به سیستم');
            
            $redirect = $_SESSION['redirect_after_login'] ?? 'dashboard.php';
            unset($_SESSION['redirect_after_login']);
            
            header('Location: ' . $redirect);
            exit;
        } else {
            throw new Exception('نام کاربری یا رمز عبور اشتباه است.');
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
        log_action('login_failed', 'تلاش ناموفق برای ورود - نام کاربری: ' . $username);
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ورود به سیستم - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo CSS_URL; ?>/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="<?php echo CSS_URL; ?>/admin.css">
    <style>
        body {
            height: 100vh;
            display: flex;
            align-items: center;
            background-color: #f5f5f5;
        }
        .login-form {
            width: 100%;
            max-width: 400px;
            padding: 15px;
            margin: auto;
        }
    </style>
</head>
<body>
    <div class="login-form">
        <div class="text-center mb-4">
            <img src="<?php echo IMAGES_URL; ?>/logo.png" alt="<?php echo SITE_NAME; ?>" height="72">
            <h1 class="h3 mb-3">ورود به سیستم</h1>
        </div>

        <div class="card">
            <div class="card-body">
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo $error ?></div>
                <?php endif; ?>

                <form method="post" class="needs-validation" novalidate>
                    <div class="mb-3">
                        <label for="username" class="form-label">نام کاربری</label>
                        <input type="text" 
                               class="form-control" 
                               id="username" 
                               name="username" 
                               value="<?php echo htmlspecialchars($_POST['username'] ?? '', ENT_QUOTES); ?>"
                               required 
                               autofocus>
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">رمز عبور</label>
                        <input type="password" 
                               class="form-control" 
                               id="password" 
                               name="password" 
                               required>
                    </div>

                    <div class="mb-3">
                        <div class="form-check">
                            <input type="checkbox" 
                                   class="form-check-input" 
                                   id="remember" 
                                   name="remember">
                            <label class="form-check-label" for="remember">
                                مرا به خاطر بسپار
                            </label>
                        </div>
                    </div>

                    <button class="w-100 btn btn-lg btn-primary" type="submit">ورود</button>
                </form>
            </div>
        </div>

        <div class="text-center mt-3">
            <a href="forgot-password.php">رمز عبور خود را فراموش کرده‌اید؟</a>
        </div>
    </div>

    <script src="<?php echo JS_URL; ?>/bootstrap.bundle.min.js"></script>
    <script>
    (function() {
        'use strict';
        var forms = document.querySelectorAll('.needs-validation');
        Array.prototype.slice.call(forms).forEach(function(form) {
            form.addEventListener('submit', function(event) {
                if (!form.checkValidity()) {
                    event.preventDefault();
                    event.stopPropagation();
                }
                form.classList.add('was-validated');
            }, false);
        });
    })();
    </script>
</body>
</html>