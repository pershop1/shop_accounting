<?php
define('ADMIN_ACCESS', true);
require_once '../../config/db.php';
require_once '../../includes/header.php';

$error = '';
$success = '';

// دریافت لیست دسته‌بندی‌ها برای فرم افزودن زیر دسته‌بندی
$sql = "SELECT id, category_name FROM categories WHERE parent_id IS NULL";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add_category') {
        $name = $_POST['name'] ?? '';
        $description = $_POST['description'] ?? '';
        $category_code = $_POST['category_code'] ?? '';
        $image = $_FILES['image'] ?? null;

        try {
            if (empty($name)) {
                throw new Exception('نام دسته‌بندی الزامی است.');
            }

            // بررسی وجود دسته‌بندی با همین نام
            $sql = "SELECT id FROM categories WHERE category_name = :name";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':name' => $name]);
            $existingCategory = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($existingCategory) {
                throw new Exception('این دسته‌بندی موجود است.');
            } else {
                if ($image && $image['error'] == 0) {
                    $imagePath = '../../uploads/' . basename($image['name']);
                    if (!move_uploaded_file($image['tmp_name'], $imagePath)) {
                        throw new Exception('آپلود تصویر با مشکل مواجه شد.');
                    }
                } else {
                    $imagePath = '../../uploads/default.png'; // تصویر پیش‌فرض
                }

                $sql = "INSERT INTO categories (category_name, description, parent_id, category_code, image, is_active, created_at) VALUES (:name, :description, :parent_id, :category_code, :image, :is_active, :created_at)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    ':name' => $name,
                    ':description' => $description,
                    ':parent_id' => null,
                    ':category_code' => $category_code,
                    ':image' => $imagePath,
                    ':is_active' => 1,
                    ':created_at' => date('Y-m-d H:i:s')
                ]);

                $success = 'دسته‌بندی با موفقیت ایجاد شد.';
            }
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
    } elseif ($action === 'add_subcategory') {
        $parent_id = $_POST['parent_id'] ?? '';
        $name = $_POST['subcategory_name'] ?? '';
        $description = $_POST['subcategory_description'] ?? '';
        $image = $_FILES['subcategory_image'] ?? null;

        try {
            if (empty($parent_id) || empty($name)) {
                throw new Exception('نام زیر دسته و دسته‌بندی اصلی الزامی است.');
            }

            // بررسی وجود زیرمنو برای دسته‌بندی
            $sql = "SELECT id FROM categories WHERE parent_id = :parent_id AND category_name = :name";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':parent_id' => $parent_id, ':name' => $name]);
            $existingSubcategory = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($existingSubcategory) {
                throw new Exception('این زیر دسته در دسته موجود است.');
            } else {
                if ($image && $image['error'] == 0) {
                    $imagePath = '../../uploads/' . basename($image['name']);
                    if (!move_uploaded_file($image['tmp_name'], $imagePath)) {
                        throw new Exception('آپلود تصویر با مشکل مواجه شد.');
                    }
                } else {
                    $imagePath = '../../uploads/default.png'; // تصویر پیش‌فرض
                }

                $sql = "INSERT INTO categories (category_name, description, parent_id, image, is_active, created_at) VALUES (:name, :description, :parent_id, :image, :is_active, :created_at)";
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    ':name' => $name,
                    ':description' => $description,
                    ':parent_id' => $parent_id,
                    ':image' => $imagePath,
                    ':is_active' => 1,
                    ':created_at' => date('Y-m-d H:i:s')
                ]);

                $success = 'زیر دسته‌بندی با موفقیت ایجاد شد.';
            }
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
    }
}

?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>افزودن دسته‌بندی - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo CSS_URL; ?>/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?php echo CSS_URL; ?>/admin.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            border: 1px solid #dc3545;
            margin-bottom: 20px;
        }
        .card-header, .btn-primary {
            background-color: #dc3545;
            border-color: #dc3545;
        }
        .card-header {
            color: white;
        }
        .btn-primary:hover {
            background-color: #c82333;
            border-color: #bd2130;
        }
        .image-container {
            position: relative;
            display: block;
            cursor: pointer;
            margin: 0 auto 20px;
            width: 200px;
            height: 200px;
        }
        .image-container img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            border-radius: 10px;
        }
        .image-container:hover .overlay {
            opacity: 1;
        }
        .overlay {
            position: absolute;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
            height: 100%;
            width: 100%;
            opacity: 0;
            transition: .5s ease;
            background-color: rgba(0, 0, 0, 0.5);
            border-radius: 10px;
        }
        .text {
            color: white;
            font-size: 16px;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-align: center;
            width: 100%;
            padding: 0 10px;
        }
        .hidden-input {
            display: none;
        }
        .suggestions {
            border: 1px solid #ccc;
            border-radius: 4px;
            max-height: 200px;
            overflow-y: auto;
            margin-top: 5px;
            background-color: #ffffff;
            position: relative;
        }
        .suggestions ul {
            list-style-type: none;
            padding: 0;
            margin: 0;
        }
        .suggestions li {
            padding: 10px;
            cursor: pointer;
        }
        .suggestions li:hover {
            background-color: #f0f0f0;
        }
        .image-section {
            text-align: center;
            padding: 20px 0;
            background-color: #f8f9fa;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .image-section h5 {
            margin-bottom: 15px;
            color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8 text-center">
                <h2 class="mb-4">افزودن دسته‌بندی و زیر دسته‌بندی</h2>
            </div>
            <div class="col-md-8">
                <!-- فرم افزودن دسته‌بندی -->
                <div class="card">
                    <div class="image-section">
                        <h5>تصویر دسته‌بندی اصلی</h5>
                        <div class="image-container" onclick="document.getElementById('image').click();">
                            <img id="image-preview" src="../../uploads/default.png" alt="پیش‌نمایش تصویر دسته‌بندی">
                            <div class="overlay">
                                <div class="text">برای انتخاب تصویر کلیک کنید</div>
                            </div>
                        </div>
                        <input type="file" id="image" name="image" class="hidden-input" accept="image/*" onchange="previewImage(event, 'image-preview')">
                    </div>

                    <div class="card-header">
                        <h4 class="mb-0">افزودن دسته‌بندی</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($error && $_POST['action'] === 'add_category'): ?>
                            <div class="alert alert-danger"><?= $error ?></div>
                        <?php endif; ?>
                        
                        <?php if ($success && $_POST['action'] === 'add_category'): ?>
                            <div class="alert alert-success"><?= $success ?></div>
                        <?php endif; ?>

                        <form method="post" enctype="multipart/form-data">
                            <input type="hidden" name="action" value="add_category">
                            <div class="mb-3">
                                <label for="name" class="form-label">نام دسته‌بندی</label>
                                <input type="text" class="form-control" id="name" name="name" required>
                            </div>
                            <div class="mb-3">
                                <label for="description" class="form-label">توضیحات</label>
                                <textarea class="form-control" id="description" name="description"></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="category_code" class="form-label">کد دسته</label>
                                <div class="input-group">
                                    <input type="text" class="form-control" id="category_code" name="category_code" readonly>
                                    <button type="button" class="btn btn-secondary" onclick="generateCategoryCode()">تولید کد</button>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">افزودن</button>
                        </form>
                    </div>
                </div>

                <!-- فرم افزودن زیر دسته‌بندی -->
                <div class="card">
                    <div class="image-section">
                        <h5>تصویر زیر دسته‌بندی</h5>
                        <div class="image-container" onclick="document.getElementById('subcategory_image').click();">
                            <img id="subcategory_image-preview" src="../../uploads/default.png" alt="پیش‌نمایش تصویر زیر دسته‌بندی">
                            <div class="overlay">
                                <div class="text">برای انتخاب تصویر کلیک کنید</div>
                            </div>
                        </div>
                        <input type="file" id="subcategory_image" name="subcategory_image" class="hidden-input" accept="image/*" onchange="previewImage(event, 'subcategory_image-preview')">
                    </div>

                    <div class="card-header">
                        <h4 class="mb-0">افزودن زیر دسته‌بندی</h4>
                    </div>
                    <div class="card-body">
                        <?php if ($error && $_POST['action'] === 'add_subcategory'): ?>
                            <div class="alert alert-danger"><?= $error ?></div>
                        <?php endif; ?>
                        
                        <?php if ($success && $_POST['action'] === 'add_subcategory'): ?>
                            <div class="alert alert-success"><?= $success ?></div>
                        <?php endif; ?>

                        <form method="post" enctype="multipart/form-data">
                            <input type="hidden" name="action" value="add_subcategory">
                            <div class="mb-3">
                                <label for="parent_id" class="form-label">انتخاب دسته‌بندی اصلی</label>
                                <input type="text" class="form-control" id="search_category" placeholder="جستجوی دسته‌بندی...">
                                <div class="suggestions" id="suggestions" style="display: none;">
                                    <ul id="suggestions_list"></ul>
                                </div>
                                <input type="hidden" id="parent_id" name="parent_id">
                            </div>
                            <div class="mb-3">
                                <label for="subcategory_name" class="form-label">نام زیر دسته‌بندی</label>
                                <input type="text" class="form-control" id="subcategory_name" name="subcategory_name" required>
                            </div>
                            <div class="mb-3">
                                <label for="subcategory_description" class="form-label">توضیحات</label>
                                <textarea class="form-control" id="subcategory_description" name="subcategory_description"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">افزودن</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?php echo JS_URL; ?>/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        // پیش‌نمایش تصویر دسته اصلی
        function previewImage(event, previewId) {
            const reader = new FileReader();
            reader.onload = function() {
                const output = document.getElementById(previewId);
                output.src = reader.result;
            };
            reader.readAsDataURL(event.target.files[0]);
        }

        // تولید کد تصادفی برای دسته‌بندی
        function generateCategoryCode() {
            const randomNumber = Math.floor(Math.random() * 1000000).toString().padStart(6, '0');
            const code = 'CAT-' + randomNumber;
            document.getElementById('category_code').value = code;
        }

        $(document).ready(function() {
            // تنظیم جستجوی دسته‌بندی‌ها
            $('#search_category').on('input', function() {
                var query = $(this).val();
                if (query.length > 0) {
                    $.ajax({
                        url: 'search_category.php',
                        method: 'GET',
                        data: { q: query },
                        dataType: 'json', // تنظیم نوع داده به JSON
                        success: function(categories) {
                            var suggestions = $('#suggestions');
                            var suggestions_list = $('#suggestions_list');
                            suggestions_list.empty();
                            
                            if (Array.isArray(categories) && categories.length > 0) {
                                categories.forEach(function(category) {
                                    suggestions_list.append(
                                        '<li data-id="' + category.id + '">' + 
                                        category.category_name + 
                                        '</li>'
                                    );
                                });
                                suggestions.show();
                            } else {
                                suggestions.hide();
                            }
                        },
                        error: function(xhr, status, error) {
                            console.error('خطا در جستجو:', error);
                            $('#suggestions').hide();
                        }
                    });
                } else {
                    $('#suggestions').hide();
                }
            });

            // انتخاب دسته‌بندی از لیست پیشنهادها
            $(document).on('click', '#suggestions_list li', function() {
                var category_id = $(this).data('id');
                var category_name = $(this).text();
                $('#parent_id').val(category_id);
                $('#search_category').val(category_name);
                $('#suggestions').hide();
            });

            // مخفی کردن لیست پیشنهادها با کلیک خارج از آن
            $(document).click(function(event) {
                if (!$(event.target).closest('#search_category, #suggestions').length) {
                    $('#suggestions').hide();
                }
            });

            // اعتبارسنجی فرم‌ها قبل از ارسال
            $('form').on('submit', function(e) {
                var form = $(this);
                var isValid = true;

                // بررسی فیلدهای اجباری
                form.find('[required]').each(function() {
                    if (!$(this).val()) {
                        isValid = false;
                        $(this).addClass('is-invalid');
                    } else {
                        $(this).removeClass('is-invalid');
                    }
                });

                if (!isValid) {
                    e.preventDefault();
                    alert('لطفاً تمام فیلدهای اجباری را پر کنید.');
                }
            });

            // پاک کردن کلاس is-invalid هنگام تایپ
            $('input, textarea').on('input', function() {
                $(this).removeClass('is-invalid');
            });
        });
    </script>
</body>
</html>
<?php require_once '../../includes/footer.php'; ?>