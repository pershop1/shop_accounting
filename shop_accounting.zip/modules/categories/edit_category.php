<?php
require_once '../../config/db.php';

$error = '';
$success = '';

$id = $_GET['id'] ?? 0;
$category = db_get_row("SELECT * FROM categories WHERE id = ?", [$id]);

if (!$category) {
    die('دسته‌بندی مورد نظر یافت نشد.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $description = $_POST['description'] ?? '';
    
    try {
        if (empty($name)) {
            throw new Exception('نام دسته‌بندی الزامی است.');
        }

        $sql = "UPDATE categories SET name = :name, description = :description WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':name' => $name,
            ':description' => $description,
            ':id' => $id
        ]);

        $success = 'دسته‌بندی با موفقیت ویرایش شد.';
        $category = db_get_row("SELECT * FROM categories WHERE id = ?", [$id]);
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ویرایش دسته‌بندی</title>
    <link rel="stylesheet" href="../../assets/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="../../assets/css/admin.css">
</head>
<body>
    <div class="container">
        <h1 class="mt-5">ویرایش دسته‌بندی</h1>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success"><?= $success ?></div>
        <?php endif; ?>

        <form method="post">
            <div class="mb-3">
                <label for="name" class="form-label">نام دسته‌بندی</label>
                <input type="text" class="form-control" id="name" name="name" value="<?= $category['name'] ?>" required>
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">توضیحات</label>
                <textarea class="form-control" id="description" name="description"><?= $category['description'] ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">ویرایش</button>
        </form>
    </div>
</body>
</html>