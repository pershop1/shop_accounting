<?php
define('ADMIN_ACCESS', true);
session_start();

// پردازش درخواست‌های POST قبل از هر خروجی
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once '../../config/db.php';
    
    // تغییر وضعیت فعال/غیرفعال
    if (isset($_POST['toggle_status']) && isset($_POST['category_id'])) {
        $category_id = (int)$_POST['category_id'];
        
        try {
            $status_sql = "UPDATE categories SET is_active = NOT is_active WHERE id = :id";
            $status_stmt = $pdo->prepare($status_sql);
            $status_stmt->execute([':id' => $category_id]);
            
            $_SESSION['success'] = 'وضعیت دسته‌بندی با موفقیت تغییر کرد.';
        } catch (PDOException $e) {
            $_SESSION['error'] = 'خطا در تغییر وضعیت: ' . $e->getMessage();
        }
        
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }

    // حذف دسته‌بندی
    if (isset($_POST['delete']) && isset($_POST['category_id'])) {
        $category_id = (int)$_POST['category_id'];
        
        try {
            // بررسی وجود زیر دسته
            $check_sql = "SELECT COUNT(*) as count FROM categories WHERE parent_id = :id";
            $check_stmt = $pdo->prepare($check_sql);
            $check_stmt->execute([':id' => $category_id]);
            $has_subcategories = $check_stmt->fetch(PDO::FETCH_ASSOC)['count'] > 0;

            if ($has_subcategories) {
                $_SESSION['error'] = 'این دسته‌بندی دارای زیر دسته است و نمی‌تواند حذف شود.';
            } else {
                // حذف تصویر دسته‌بندی
                $img_sql = "SELECT image FROM categories WHERE id = :id";
                $img_stmt = $pdo->prepare($img_sql);
                $img_stmt->execute([':id' => $category_id]);
                $image_path = $img_stmt->fetch(PDO::FETCH_ASSOC)['image'];

                if ($image_path && $image_path !== '../../uploads/default.png' && file_exists($image_path)) {
                    unlink($image_path);
                }

                // حذف دسته‌بندی
                $delete_sql = "DELETE FROM categories WHERE id = :id";
                $delete_stmt = $pdo->prepare($delete_sql);
                $delete_stmt->execute([':id' => $category_id]);

                $_SESSION['success'] = 'دسته‌بندی با موفقیت حذف شد.';
            }
        } catch (PDOException $e) {
            $_SESSION['error'] = 'خطا در حذف دسته‌بندی: ' . $e->getMessage();
        }
        
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit;
    }
}

require_once '../../config/db.php';
require_once '../../includes/header.php';

// تنظیمات مربوط به صفحه‌بندی
$records_per_page = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $records_per_page;

// شمارش کل دسته‌بندی‌ها برای صفحه‌بندی
$count_sql = "SELECT COUNT(*) as total FROM categories";
$count_stmt = $pdo->prepare($count_sql);
$count_stmt->execute();
$total_records = $count_stmt->fetch(PDO::FETCH_ASSOC)['total'];
$total_pages = ceil($total_records / $records_per_page);

// دریافت لیست دسته‌بندی‌ها با اطلاعات مربوط به والد
$sql = "SELECT c.*, 
               p.category_name as parent_name,
               (SELECT COUNT(*) FROM categories WHERE parent_id = c.id) as subcategories_count
        FROM categories c 
        LEFT JOIN categories p ON c.parent_id = p.id
        ORDER BY c.created_at DESC
        LIMIT :offset, :limit";

$stmt = $pdo->prepare($sql);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->bindValue(':limit', $records_per_page, PDO::PARAM_INT);
$stmt->execute();
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

// پیام‌های موفقیت و خطا
$success = isset($_SESSION['success']) ? $_SESSION['success'] : '';
$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';
unset($_SESSION['success'], $_SESSION['error']);
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لیست دسته‌بندی‌ها - <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="<?php echo CSS_URL; ?>/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="<?php echo CSS_URL; ?>/admin.css">
    <style>
        .table-responsive {
            margin-top: 20px;
        }
        .category-image {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 5px;
        }
        .status-badge {
            min-width: 100px;
        }
        .pagination {
            justify-content: center;
            margin-top: 20px;
        }
        .alert {
            margin-top: 20px;
        }
        .action-buttons {
            display: flex;
            gap: 5px;
            justify-content: center;
        }
        .category-name {
            max-width: 200px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        @media (max-width: 768px) {
            .table-responsive {
                font-size: 14px;
            }
            .category-image {
                width: 40px;
                height: 40px;
            }
            .status-badge {
                min-width: auto;
            }
            .action-buttons {
                flex-direction: column;
            }
            .action-buttons .btn {
                padding: 0.25rem 0.5rem;
                font-size: 12px;
            }
        }
    </style>
</head>
<body>
    <div class="container-fluid mt-3">
        <div class="row">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h2>لیست دسته‌بندی‌ها</h2>
                    <a href="add_category.php" class="btn btn-primary">
                        <i class="bi bi-plus-lg"></i>
                        افزودن دسته‌بندی جدید
                    </a>
                </div>

                <?php if ($success): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo $success; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <div class="table-responsive">
                    <table class="table table-hover table-bordered">
                        <thead class="table-dark">
                            <tr>
                                <th scope="col" class="text-center">#</th>
                                <th scope="col" class="text-center">تصویر</th>
                                <th scope="col">نام دسته‌بندی</th>
                                <th scope="col">دسته والد</th>
                                <th scope="col" class="text-center">تعداد زیر دسته</th>
                                <th scope="col" class="text-center">کد دسته</th>
                                <th scope="col" class="text-center">وضعیت</th>
                                <th scope="col" class="text-center">تاریخ ایجاد</th>
                                <th scope="col" class="text-center">عملیات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($categories as $index => $category): ?>
                                <tr>
                                    <td class="text-center"><?php echo $offset + $index + 1; ?></td>
                                    <td class="text-center">
                                        <img src="<?php echo htmlspecialchars($category['image'] ?? '../../uploads/default.png'); ?>" 
                                             alt="تصویر دسته‌بندی" 
                                             class="category-image">
                                    </td>
                                    <td class="category-name">
                                        <?php echo htmlspecialchars($category['category_name'] ?? ''); ?>
                                    </td>
                                    <td>
                                        <?php echo htmlspecialchars($category['parent_name'] ?? 'دسته اصلی'); ?>
                                    </td>
                                    <td class="text-center">
                                        <?php echo (int)$category['subcategories_count']; ?>
                                    </td>
                                    <td class="text-center">
                                        <?php echo htmlspecialchars($category['category_code'] ?? '-'); ?>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge <?php echo $category['is_active'] ? 'bg-success' : 'bg-danger'; ?> status-badge">
                                            <?php echo $category['is_active'] ? 'فعال' : 'غیرفعال'; ?>
                                        </span>
                                    </td>
                                    <td class="text-center" dir="ltr">
                                        <?php echo $category['created_at']; ?>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="edit_category.php?id=<?php echo $category['id']; ?>" 
                                               class="btn btn-warning btn-sm">
                                                <i class="bi bi-pencil"></i>
                                                ویرایش
                                            </a>
                                            
                                            <form method="post" class="d-inline" 
                                                  onsubmit="return confirm('آیا از حذف این دسته‌بندی اطمینان دارید؟');">
                                                <input type="hidden" name="category_id" 
                                                       value="<?php echo $category['id']; ?>">
                                                <button type="submit" name="delete" class="btn btn-danger btn-sm">
                                                    <i class="bi bi-trash"></i>
                                                    حذف
                                                </button>
                                            </form>

                                            <form method="post" class="d-inline">
                                                <input type="hidden" name="category_id" 
                                                       value="<?php echo $category['id']; ?>">
                                                <button type="submit" name="toggle_status" 
                                                        class="btn <?php echo $category['is_active'] ? 'btn-secondary' : 'btn-success'; ?> btn-sm">
                                                    <i class="bi <?php echo $category['is_active'] ? 'bi-x-lg' : 'bi-check-lg'; ?>"></i>
                                                    <?php echo $category['is_active'] ? 'غیرفعال کردن' : 'فعال کردن'; ?>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            <?php if (empty($categories)): ?>
                                <tr>
                                    <td colspan="9" class="text-center">هیچ دسته‌بندی یافت نشد.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($total_pages > 1): ?>
                    <nav aria-label="صفحه‌بندی">
                        <ul class="pagination">
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=1">
                                        <i class="bi bi-chevron-double-right"></i>
                                    </a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo $page - 1; ?>">
                                        <i class="bi bi-chevron-right"></i>
                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php
                            $start_page = max(1, $page - 2);
                            $end_page = min($total_pages, $page + 2);
                            
                            for ($i = $start_page; $i <= $end_page; $i++): 
                            ?>
                                <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>">
                                        <?php echo $i; ?>
                                    </a>
                                </li>
                            <?php endfor; ?>

                            <?php if ($page < $total_pages): ?>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo $page + 1; ?>">
                                        <i class="bi bi-chevron-left"></i>
                                    </a>
                                </li>
                                <li class="page-item">
                                    <a class="page-link" href="?page=<?php echo $total_pages; ?>">
                                        <i class="bi bi-chevron-double-left"></i>
                                    </a>
                                </li>
                                <?php endif; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="<?php echo JS_URL; ?>/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        // حذف خودکار پیام‌های نمایشی بعد از 5 ثانیه
        setTimeout(function() {
            document.querySelectorAll('.alert').forEach(function(alert) {
                new bootstrap.Alert(alert).close();
            });
        }, 5000);

        // تایید تغییر وضعیت دسته‌بندی
        document.querySelectorAll('button[name="toggle_status"]').forEach(function(button) {
            button.closest('form').addEventListener('submit', function(e) {
                if (!confirm('آیا از تغییر وضعیت این دسته‌بندی اطمینان دارید؟')) {
                    e.preventDefault();
                }
            });
        });

        // نمایش تصویر بزرگ‌تر در مودال با کلیک روی تصویر
        document.querySelectorAll('.category-image').forEach(function(img) {
            img.addEventListener('click', function() {
                const modal = document.createElement('div');
                modal.className = 'modal fade';
                modal.innerHTML = `
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">تصویر دسته‌بندی</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body text-center p-0">
                                <img src="${this.src}" class="img-fluid" style="max-height: 80vh;">
                            </div>
                        </div>
                    </div>
                `;
                document.body.appendChild(modal);
                const modalInstance = new bootstrap.Modal(modal);
                modalInstance.show();
                
                modal.addEventListener('hidden.bs.modal', function() {
                    modal.remove();
                });
            });
        });

        // تنظیم جدول برای نمایش ریسپانسیو
        function adjustTableForMobile() {
            if (window.innerWidth < 768) {
                const tableHeaders = document.querySelectorAll('table th');
                const tableRows = document.querySelectorAll('table tbody tr');
                
                tableRows.forEach(row => {
                    row.querySelectorAll('td').forEach((cell, index) => {
                        // اضافه کردن عنوان ستون به صورت data attribute
                        if (tableHeaders[index]) {
                            cell.setAttribute('data-label', tableHeaders[index].textContent.trim());
                        }
                    });
                });
            }
        }

        // اجرای تابع تنظیم جدول در لود صفحه و تغییر سایز
        window.addEventListener('load', adjustTableForMobile);
        window.addEventListener('resize', adjustTableForMobile);

        // مدیریت دکمه‌های عملیات در حالت موبایل
        function adjustActionButtons() {
            if (window.innerWidth < 768) {
                document.querySelectorAll('.action-buttons').forEach(function(buttonGroup) {
                    buttonGroup.classList.add('d-flex', 'flex-column', 'gap-2');
                    buttonGroup.querySelectorAll('.btn').forEach(function(button) {
                        button.classList.add('w-100');
                    });
                });
            } else {
                document.querySelectorAll('.action-buttons').forEach(function(buttonGroup) {
                    buttonGroup.classList.remove('d-flex', 'flex-column', 'gap-2');
                    buttonGroup.querySelectorAll('.btn').forEach(function(button) {
                        button.classList.remove('w-100');
                    });
                });
            }
        }

        // اجرای تابع تنظیم دکمه‌ها در لود صفحه و تغییر سایز
        window.addEventListener('load', adjustActionButtons);
        window.addEventListener('resize', adjustActionButtons);
    </script>
</body>
</html>
<?php require_once '../../includes/footer.php'; ?>