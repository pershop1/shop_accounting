<?php
/**
 * صفحه افزودن محصول جدید
 * تاریخ: ۲۹ اسفند ۱۴۰۲
 */

// بارگذاری تنظیمات
require_once '../../config/config.php';

// بررسی دسترسی کاربر
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role'])) {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

// بررسی مجوز دسترسی
$allowedRoles = ['admin', 'manager', 'stockkeeper'];
if (!in_array($_SESSION['user_role'], $allowedRoles)) {
    die('شما مجوز دسترسی به این بخش را ندارید.');
}

// متغیرهای پیش‌فرض
$errors = [];
$success = false;
$product = [
    'name' => '',
    'code' => '',
    'barcode' => '',
    'category_id' => '',
    'buy_price' => '',
    'sell_price' => '',
    'stock' => '',
    'min_stock' => '',
    'description' => '',
    'status' => 1
];

// دریافت لیست دسته‌بندی‌ها
try {
    $stmt = $pdo->prepare("SELECT id, name FROM categories WHERE status = 1 ORDER BY name");
    $stmt->execute();
    $categories = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log($e->getMessage());
    $errors[] = 'خطا در دریافت لیست دسته‌بندی‌ها';
}

// پردازش فرم
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // دریافت داده‌ها
    $product = [
        'name' => trim($_POST['name'] ?? ''),
        'code' => trim($_POST['code'] ?? ''),
        'barcode' => trim($_POST['barcode'] ?? ''),
        'category_id' => $_POST['category_id'] ?? '',
        'buy_price' => str_replace(',', '', $_POST['buy_price'] ?? ''),
        'sell_price' => str_replace(',', '', $_POST['sell_price'] ?? ''),
        'stock' => $_POST['stock'] ?? '',
        'min_stock' => $_POST['min_stock'] ?? '',
        'description' => trim($_POST['description'] ?? ''),
        'status' => isset($_POST['status']) ? 1 : 0
    ];

    // اعتبارسنجی داده‌ها
    if (empty($product['name'])) {
        $errors[] = 'نام محصول الزامی است';
    }
    if (empty($product['code'])) {
        $errors[] = 'کد محصول الزامی است';
    }
    if (empty($product['category_id'])) {
        $errors[] = 'دسته‌بندی محصول الزامی است';
    }
    if (!is_numeric($product['buy_price']) || $product['buy_price'] < 0) {
        $errors[] = 'قیمت خرید باید عدد مثبت باشد';
    }
    if (!is_numeric($product['sell_price']) || $product['sell_price'] < 0) {
        $errors[] = 'قیمت فروش باید عدد مثبت باشد';
    }
    if (!is_numeric($product['stock']) || $product['stock'] < 0) {
        $errors[] = 'موجودی باید عدد مثبت باشد';
    }

    // بررسی تکراری نبودن کد محصول
    try {
        $stmt = $pdo->prepare("SELECT id FROM products WHERE code = ? AND id != ?");
        $stmt->execute([$product['code'], 0]);
        if ($stmt->rowCount() > 0) {
            $errors[] = 'این کد محصول قبلاً ثبت شده است';
        }
    } catch (PDOException $e) {
        error_log($e->getMessage());
        $errors[] = 'خطا در بررسی کد محصول';
    }

    // آپلود تصویر محصول
    $image_path = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $max_size = 5 * 1024 * 1024; // 5MB

        if (!in_array($_FILES['image']['type'], $allowed_types)) {
            $errors[] = 'فرمت تصویر مجاز نیست. فقط jpg, png و gif مجاز هستند';
        } elseif ($_FILES['image']['size'] > $max_size) {
            $errors[] = 'حجم تصویر نباید بیشتر از 5 مگابایت باشد';
        } else {
            $extension = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $image_path = 'uploads/products/' . uniqid() . '.' . $extension;
            
            if (!move_uploaded_file($_FILES['image']['tmp_name'], $image_path)) {
                $errors[] = 'خطا در آپلود تصویر';
            }
        }
    }

    // ذخیره اطلاعات
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();

            $sql = "INSERT INTO products (
                name, code, barcode, category_id, buy_price, sell_price,
                stock, min_stock, description, image, status, created_at, created_by
            ) VALUES (
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?
            )";

            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $product['name'],
                $product['code'],
                $product['barcode'],
                $product['category_id'],
                $product['buy_price'],
                $product['sell_price'],
                $product['stock'],
                $product['min_stock'],
                $product['description'],
                $image_path,
                $product['status'],
                $_SESSION['user_id']
            ]);

            // ثبت در گزارش موجودی
            if ($product['stock'] > 0) {
                $product_id = $pdo->lastInsertId();
                $sql = "INSERT INTO inventory_log (
                    product_id, type, quantity, description, created_at, created_by
                ) VALUES (
                    ?, 'in', ?, 'موجودی اولیه', NOW(), ?
                )";
                
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    $product_id,
                    $product['stock'],
                    $_SESSION['user_id']
                ]);
            }

            $pdo->commit();
            $success = true;
            
            // پاک کردن داده‌های فرم
            $product = [
                'name' => '',
                'code' => '',
                'barcode' => '',
                'category_id' => '',
                'buy_price' => '',
                'sell_price' => '',
                'stock' => '',
                'min_stock' => '',
                'description' => '',
                'status' => 1
            ];

        } catch (PDOException $e) {
            $pdo->rollBack();
            error_log($e->getMessage());
            $errors[] = 'خطا در ثبت اطلاعات';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>افزودن محصول جدید - سیستم حسابداری فروشگاه</title>
    <link rel="stylesheet" href="../../assets/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
<?php require_once '../../includes/header.php'; ?>

    <div class="container py-4">
        <div class="row">
            <div class="col-lg-3">
            <?php require_once '../../includes/sidebar.php'; ?>
            </div>
            <div class="col-lg-9">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">افزودن محصول جدید</h3>
                    </div>
                    <div class="card-body">
                        <?php if ($success): ?>
                            <div class="alert alert-success">
                                محصول با موفقیت ثبت شد.
                                <a href="list.php" class="alert-link">مشاهده لیست محصولات</a>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($errors)): ?>
                            <div class="alert alert-danger">
                                <ul class="mb-0">
                                    <?php foreach ($errors as $error): ?>
                                        <li><?php echo $error; ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form method="post" enctype="multipart/form-data" class="row">
                            <div class="col-md-6 mb-3">
                                <label for="name" class="form-label">نام محصول <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="name" name="name" 
                                       value="<?php echo htmlspecialchars($product['name']); ?>" required>
                            </div>

                            <div class="col-md-3 mb-3">
                                <label for="code" class="form-label">کد محصول <span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="code" name="code" 
                                       value="<?php echo htmlspecialchars($product['code']); ?>" required>
                            </div>

                            <div class="col-md-3 mb-3">
                                <label for="barcode" class="form-label">بارکد</label>
                                <input type="text" class="form-control" id="barcode" name="barcode" 
                                       value="<?php echo htmlspecialchars($product['barcode']); ?>">
                            </div>

                            <div class="col-md-6 mb-3">
                                <label for="category_id" class="form-label">دسته‌بندی <span class="text-danger">*</span></label>
                                <select class="form-select" id="category_id" name="category_id" required>
                                    <option value="">انتخاب کنید</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?php echo $category['id']; ?>" 
                                            <?php echo ($category['id'] == $product['category_id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($category['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="col-md-3 mb-3">
                                <label for="buy_price" class="form-label">قیمت خرید <span class="text-danger">*</span></label>
                                <input type="text" class="form-control number-format" id="buy_price" name="buy_price" 
                                       value="<?php echo number_format($product['buy_price']); ?>" required>
                            </div>

                            <div class="col-md-3 mb-3">
                                <label for="sell_price" class="form-label">قیمت فروش <span class="text-danger">*</span></label>
                                <input type="text" class="form-control number-format" id="sell_price" name="sell_price" 
                                       value="<?php echo number_format($product['sell_price']); ?>" required>
                            </div>

                            <div class="col-md-3 mb-3">
                                <label for="stock" class="form-label">موجودی <span class="text-danger">*</span></label>
                                <input type="number" class="form-control" id="stock" name="stock" 
                                       value="<?php echo htmlspecialchars($product['stock']); ?>" required>
                            </div>

                            <div class="col-md-3 mb-3">
                                <label for="min_stock" class="form-label">حداقل موجودی</label>
                                <input type="number" class="form-control" id="min_stock" name="min_stock" 
                                       value="<?php echo htmlspecialchars($product['min_stock']); ?>">
                            </div>

                            <div class="col-md-6 mb-3">
                                <label for="image" class="form-label">تصویر محصول</label>
                                <input type="file" class="form-control" id="image" name="image" accept="image/*">
                                <small class="text-muted">فرمت‌های مجاز: jpg, png, gif - حداکثر حجم: 5 مگابایت</small>
                            </div>

                            <div class="col-12 mb-3">
                                <label for="description" class="form-label">توضیحات</label>
                                <textarea class="form-control" id="description" name="description" rows="3"><?php echo htmlspecialchars($product['description']); ?></textarea>
                            </div>

                            <div class="col-12 mb-3">
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" id="status" name="status" value="1" 
                                           <?php echo $product['status'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="status">فعال</label>
                                </div>
                            </div>

                            <div class="col-12">
                                <button type="submit" class="btn btn-primary">ذخیره محصول</button>
                                <a href="list.php" class="btn btn-secondary">انصراف</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php require_once '../../includes/footer.php'; ?>

    <script src="../../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../../assets/js/jquery-3.6.0.min.js"></script>
    <!-- افزودن کتابخانه برای فرمت‌بندی اعداد -->
    <script src="../../assets/js/jquery.number.min.js"></script>
    <script>
        $(document).ready(function() {
            // فرمت‌بندی فیلدهای عددی
            $('.number-format').on('input', function() {
                var value = $(this).val().replace(/,/g, '');
                if (value !== '' && !isNaN(value)) {
                    $(this).val($.number(value, 0));
                }
            });

            // تولید خودکار بارکد
            $('#generate-barcode').click(function(e) {
                e.preventDefault();
                var timestamp = new Date().getTime().toString().slice(-12);
                $('#barcode').val(timestamp);
            });

            // نمایش پیش‌نمایش تصویر
            $('#image').change(function() {
                if (this.files && this.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        $('#image-preview').attr('src', e.target.result).show();
                    }
                    reader.readAsDataURL(this.files[0]);
                }
            });

            // محاسبه خودکار قیمت فروش
            $('#buy_price').on('input', function() {
                var buyPrice = parseInt($(this).val().replace(/,/g, '')) || 0;
                var profit = Math.ceil(buyPrice * 0.2); // ۲۰ درصد سود
                var sellPrice = buyPrice + profit;
                $('#sell_price').val($.number(sellPrice, 0));
            });
        });
    </script>
</body>
</html>