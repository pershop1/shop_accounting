<?php
/**
 * صفحه لیست محصولات
 * تاریخ آخرین بروزرسانی: ۲۹ اسفند ۱۴۰۲
 */

// بارگذاری تنظیمات
require_once '../../config/config.php';

// بررسی دسترسی کاربر
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_role'])) {
    header('Location: ' . BASE_URL . '/login.php');
    exit;
}

// تعداد محصولات در هر صفحه
$per_page = PRODUCTS_PER_PAGE;

// دریافت شماره صفحه
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$page = max(1, $page);

// محاسبه شروع
$start = ($page - 1) * $per_page;

// فیلترها
$filters = [];
$where_sql = 'WHERE 1=1';
$params = [];

// جستجو
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = trim($_GET['search']);
    $where_sql .= ' AND (name LIKE ? OR code LIKE ? OR barcode LIKE ?)';
    $params = array_merge($params, ["%$search%", "%$search%", "%$search%"]);
    $filters['search'] = $search;
}

// فیلتر دسته‌بندی
if (isset($_GET['category']) && !empty($_GET['category'])) {
    $category = (int)$_GET['category'];
    $where_sql .= ' AND category_id = ?';
    $params[] = $category;
    $filters['category'] = $category;
}

// فیلتر وضعیت موجودی
if (isset($_GET['stock_status'])) {
    switch ($_GET['stock_status']) {
        case 'in_stock':
            $where_sql .= ' AND stock > 0';
            break;
        case 'low_stock':
            $where_sql .= ' AND stock <= min_stock AND stock > 0';
            break;
        case 'out_of_stock':
            $where_sql .= ' AND stock = 0';
            break;
    }
    $filters['stock_status'] = $_GET['stock_status'];
}

// فیلتر وضعیت
if (isset($_GET['status'])) {
    $status = (int)$_GET['status'];
    $where_sql .= ' AND status = ?';
    $params[] = $status;
    $filters['status'] = $status;
}

try {
    // دریافت تعداد کل محصولات
    $stmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM products 
        $where_sql
    ");
    $stmt->execute($params);
    $total_records = $stmt->fetchColumn();
    
    // محاسبه تعداد کل صفحات
    $total_pages = ceil($total_records / $per_page);
    $page = min($page, $total_pages);
    
    // دریافت لیست محصولات
    $stmt = $pdo->prepare("
        SELECT 
            p.*,
            c.name as category_name,
            COALESCE(SUM(s.quantity), 0) as total_sales
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        LEFT JOIN sales_items s ON p.id = s.product_id
        $where_sql
        GROUP BY p.id
        ORDER BY p.created_at DESC
        LIMIT ? OFFSET ?
    ");
    
    $params[] = $per_page;
    $params[] = $start;
    $stmt->execute($params);
    $products = $stmt->fetchAll();
    
    // دریافت لیست دسته‌بندی‌ها برای فیلتر
    $stmt = $pdo->query("SELECT id, name FROM categories WHERE status = 1 ORDER BY name");
    $categories = $stmt->fetchAll();
    
} catch (PDOException $e) {
    error_log($e->getMessage());
    $_SESSION['error'] = 'خطا در دریافت اطلاعات';
    $products = [];
    $total_pages = 0;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لیست محصولات - سیستم حسابداری فروشگاه</title>
    <link rel="stylesheet" href="../../assets/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="../../assets/css/style.css">
</head>
<body>
    <?php require_once '../includes/header.php'; ?>

    <div class="container py-4">
        <div class="row">
            <div class="col-lg-3">
                <?php require_once '../includes/sidebar.php'; ?>
            </div>
            <div class="col-lg-9">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h3 class="card-title mb-0">لیست محصولات</h3>
                        <a href="add.php" class="btn btn-primary">افزودن محصول جدید</a>
                    </div>
                    <div class="card-body">
                        <!-- فرم فیلتر -->
                        <form method="get" class="row g-3 mb-4">
                            <div class="col-md-4">
                                <input type="text" class="form-control" name="search" 
                                       placeholder="جستجو..." value="<?php echo $filters['search'] ?? ''; ?>">
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" name="category">
                                    <option value="">همه دسته‌بندی‌ها</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?php echo $category['id']; ?>" 
                                            <?php echo (isset($filters['category']) && $filters['category'] == $category['id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($category['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-3">
                                <select class="form-select" name="stock_status">
                                    <option value="">وضعیت موجودی</option>
                                    <option value="in_stock" <?php echo (isset($filters['stock_status']) && $filters['stock_status'] == 'in_stock') ? 'selected' : ''; ?>>
                                        موجود
                                    </option>
                                    <option value="low_stock" <?php echo (isset($filters['stock_status']) && $filters['stock_status'] == 'low_stock') ? 'selected' : ''; ?>>
                                        رو به اتمام
                                    </option>
                                    <option value="out_of_stock" <?php echo (isset($filters['stock_status']) && $filters['stock_status'] == 'out_of_stock') ? 'selected' : ''; ?>>
                                        ناموجود
                                    </option>
                                </select>
                            </div>
                            <div class="col-md-2">
                                <button type="submit" class="btn btn-primary w-100">فیلتر</button>
                            </div>
                        </form>

                        <!-- جدول محصولات -->
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>تصویر</th>
                                        <th>نام محصول</th>
                                        <th>کد</th>
                                        <th>دسته‌بندی</th>
                                        <th>قیمت فروش</th>
                                        <th>موجودی</th>
                                        <th>وضعیت</th>
                                        <th>عملیات</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($products)): ?>
                                        <tr>
                                            <td colspan="8" class="text-center">محصولی یافت نشد</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($products as $product): ?>
                                            <tr>
                                                <td>
                                                    <?php if ($product['image']): ?>
                                                        <img src="<?php echo BASE_URL . '/' . $product['image']; ?>" 
                                                             alt="<?php echo htmlspecialchars($product['name']); ?>" 
                                                             class="img-thumbnail" style="width: 50px;">
                                                    <?php else: ?>
                                                        <img src="<?php echo DEFAULT_PRODUCT_IMAGE; ?>" 
                                                             alt="بدون تصویر" 
                                                             class="img-thumbnail" style="width: 50px;">
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo htmlspecialchars($product['name']); ?></td>
                                                <td><?php echo htmlspecialchars($product['code']); ?></td>
                                                <td><?php echo htmlspecialchars($product['category_name']); ?></td>
                                                <td><?php echo number_format($product['sell_price']); ?> تومان</td>
                                                <td>
                                                    <?php if ($product['stock'] <= $product['min_stock'] && $product['stock'] > 0): ?>
                                                        <span class="badge bg-warning"><?php echo $product['stock']; ?></span>
                                                    <?php elseif ($product['stock'] == 0): ?>
                                                        <span class="badge bg-danger">ناموجود</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-success"><?php echo $product['stock']; ?></span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if ($product['status']): ?>
                                                        <span class="badge bg-success">فعال</span>
                                                    <?php else: ?>
                                                        <span class="badge bg-danger">غیرفعال</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <div class="btn-group btn-group-sm">
                                                        <a href="edit.php?id=<?php echo $product['id']; ?>" 
                                                           class="btn btn-warning" title="ویرایش">
                                                            <i class="bi bi-pencil"></i>
                                                        </a>
                                                        <a href="inventory.php?id=<?php echo $product['id']; ?>" 
                                                           class="btn btn-info" title="موجودی">
                                                            <i class="bi bi-box"></i>
                                                        </a>
                                                        <button type="button" 
                                                                class="btn btn-danger delete-product" 
                                                                data-id="<?php echo $product['id']; ?>" 
                                                                data-name="<?php echo htmlspecialchars($product['name']); ?>"
                                                                title="حذف">
                                                            <i class="bi bi-trash"></i>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                        <!-- صفحه‌بندی -->
                        <?php if ($total_pages > 1): ?>
                            <nav class="mt-4">
                                <ul class="pagination justify-content-center">
                                    <?php if ($page > 1): ?>
                                        <li class="page-item">
                                            <a class="page-link" href="?page=1<?php echo isset($_GET['search']) ? '&search='.$_GET['search'] : ''; ?>">
                                                اولین
                                            </a>
                                        </li>
                                        <li class="page-item">
                                            <a class="page-link" href="?page=<?php echo $page - 1; ?><?php echo isset($_GET['search']) ? '&search='.$_GET['search'] : ''; ?>">
                                                قبلی
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <?php
                                    $start_page = max(1, $page - 2);
                                    $end_page = min($total_pages, $page + 2);

                                    for ($i = $start_page; $i <= $end_page; $i++):
                                    ?>
                                        <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                                            <a class="page-link" href="?page=<?php echo $i; ?><?php echo isset($_GET['search']) ? '&search='.$_GET['search'] : ''; ?>">
                                                <?php echo $i; ?>
                                            </a>
                                        </li>
                                    <?php endfor; ?>

                                    <?php if ($page < $total_pages): ?>
                                        <li class="page-item">
                                            <a class="page-link" href="?page=<?php echo $page + 1; ?><?php echo isset($_GET['search']) ? '&search='.$_GET['search'] : ''; ?>">
                                                بعدی
                                            </a>
                                        </li>
                                        <li class="page-item">
                                            <a class="page-link" href="?page=<?php echo $total_pages; ?><?php echo isset($_GET['search']) ? '&search='.$_GET['search'] : ''; ?>">
                                                آخرین
                                            </a>
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </nav>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php require_once '../includes/footer.php'; ?>

        <!-- مودال حذف محصول -->
        <div class="modal fade" id="deleteModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">تأیید حذف محصول</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>آیا از حذف محصول "<span id="deleteProductName"></span>" اطمینان دارید؟</p>
                    <p class="text-danger">این عملیات قابل بازگشت نیست.</p>
                </div>
                <div class="modal-footer">
                    <form id="deleteForm" method="post" action="delete.php">
                        <input type="hidden" name="product_id" id="deleteProductId">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">انصراف</button>
                        <button type="submit" class="btn btn-danger">حذف</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="../../assets/js/bootstrap.bundle.min.js"></script>
    <script src="../../assets/js/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // نمایش مودال حذف
            $('.delete-product').click(function() {
                var id = $(this).data('id');
                var name = $(this).data('name');
                $('#deleteProductId').val(id);
                $('#deleteProductName').text(name);
                $('#deleteModal').modal('show');
            });

            // فرمت کردن اعداد
            $('.number-format').each(function() {
                var num = $(this).text();
                $(this).text(new Intl.NumberFormat('fa-IR').format(num));
            });

            // تایید فرم فیلتر
            $('#filter-form').submit(function() {
                var hasFilter = false;
                $(this).find('input, select').each(function() {
                    if ($(this).val()) {
                        hasFilter = true;
                        return false;
                    }
                });
                if (!hasFilter) {
                    alert('لطفاً حداقل یک فیلتر را انتخاب کنید');
                    return false;
                }
            });

            // نمایش پیش‌نمایش تصویر
            $('.product-image').click(function() {
                var src = $(this).attr('src');
                var name = $(this).data('name');
                $('#imagePreviewSrc').attr('src', src);
                $('#imagePreviewName').text(name);
                $('#imagePreviewModal').modal('show');
            });

            // بروزرسانی وضعیت محصول
            $('.toggle-status').change(function() {
                var id = $(this).data('id');
                var status = $(this).prop('checked') ? 1 : 0;
                
                $.ajax({
                    url: 'ajax/update_status.php',
                    method: 'POST',
                    data: {
                        product_id: id,
                        status: status
                    },
                    success: function(response) {
                        if (response.success) {
                            alert('وضعیت محصول با موفقیت بروزرسانی شد');
                        } else {
                            alert('خطا در بروزرسانی وضعیت محصول');
                        }
                    },
                    error: function() {
                        alert('خطا در ارتباط با سرور');
                    }
                });
            });

            // فیلتر پیشرفته
            $('#advancedFilterToggle').click(function() {
                $('#advancedFilters').slideToggle();
            });

            // پاک کردن فیلترها
            $('#clearFilters').click(function() {
                $('#filter-form').find('input, select').val('');
                $('#filter-form').submit();
            });

            // صادرات به اکسل
            $('#exportExcel').click(function() {
                var filters = $('#filter-form').serialize();
                window.location.href = 'export.php?' + filters;
            });

            // چاپ لیست
            $('#printList').click(function() {
                window.print();
            });
        });
    </script>
</body>
</html>