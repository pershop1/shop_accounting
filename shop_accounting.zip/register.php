<?php
require_once 'config/config.php';
require_once 'config/db.php';
require_once 'includes/functions.php';

// اگر کاربر لاگین کرده است، به داشبورد منتقل شود
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
    exit;
}

// ایجاد توکن CSRF برای امنیت فرم
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die('توکن CSRF نامعتبر است.');
    }

    // دریافت و پاکسازی داده‌های فرم
    $username = sanitize($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $full_name = sanitize($_POST['full_name']);
    $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
    $mobile = sanitize($_POST['mobile']);
    
    // اعتبارسنجی نام کاربری
    if (empty($username)) {
        $errors['username'] = 'نام کاربری الزامی است';
    } elseif (strlen($username) < 4 || strlen($username) > 50) {
        $errors['username'] = 'نام کاربری باید بین 4 تا 50 حرف باشد';
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
        $errors['username'] = 'نام کاربری فقط می‌تواند شامل حروف انگلیسی، اعداد و _ باشد';
    } else {
        // بررسی تکراری نبودن نام کاربری
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        if ($stmt->rowCount() > 0) {
            $errors['username'] = 'این نام کاربری قبلاً ثبت شده است';
        }
    }
    
    // اعتبارسنجی رمز عبور
    if (empty($password)) {
        $errors['password'] = 'رمز عبور الزامی است';
    } elseif (strlen($password) < 8) {
        $errors['password'] = 'رمز عبور باید حداقل 8 کاراکتر باشد';
    } elseif (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/', $password)) {
        $errors['password'] = 'رمز عبور باید شامل حروف بزرگ، کوچک و اعداد باشد';
    } elseif ($password !== $confirm_password) {
        $errors['confirm_password'] = 'رمز عبور و تکرار آن یکسان نیستند';
    }
    
    // اعتبارسنجی نام و نام خانوادگی
    if (empty($full_name)) {
        $errors['full_name'] = 'نام و نام خانوادگی الزامی است';
    } elseif (strlen($full_name) > 100) {
        $errors['full_name'] = 'نام و نام خانوادگی نمی‌تواند بیشتر از 100 حرف باشد';
    }
    
    // اعتبارسنجی ایمیل
    if (empty($email)) {
        $errors['email'] = 'ایمیل الزامی است';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'ایمیل معتبر نیست';
    } else {
        // بررسی تکراری نبودن ایمیل
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->rowCount() > 0) {
            $errors['email'] = 'این ایمیل قبلاً ثبت شده است';
        }
    }
    
    // اعتبارسنجی موبایل
    if (!empty($mobile)) {
        if (!preg_match('/^09[0-9]{9}$/', $mobile)) {
            $errors['mobile'] = 'شماره موبایل معتبر نیست';
        } else {
            // بررسی تکراری نبودن موبایل
            $stmt = $pdo->prepare("SELECT id FROM users WHERE mobile = ?");
            $stmt->execute([$mobile]);
            if ($stmt->rowCount() > 0) {
                $errors['mobile'] = 'این شماره موبایل قبلاً ثبت شده است';
            }
        }
    }
    
    // اگر خطایی وجود نداشت، ثبت‌نام انجام شود
    if (empty($errors)) {
        try {
            // ایجاد کد فعال‌سازی
            $activation_code = md5(uniqid(rand(), true));
            
            // هش کردن رمز عبور
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // درج اطلاعات کاربر
            $stmt = $pdo->prepare("
                INSERT INTO users (username, password, full_name, email, mobile, activation_code, role)
                VALUES (?, ?, ?, ?, ?, ?, 'user')
            ");
            
            $stmt->execute([
                $username,
                $hashed_password,
                $full_name,
                $email,
                $mobile,
                $activation_code
            ]);
            
            // ارسال ایمیل فعال‌سازی
            $activation_link = BASE_URL . '/activate.php?code=' . $activation_code;
            
            $email_template = file_get_contents('templates/emails/activation.html');
            $email_template = str_replace(
                ['{{full_name}}', '{{activation_link}}'],
                [$full_name, $activation_link],
                $email_template
            );
            
            if (send_mail($email, 'فعال‌سازی حساب کاربری', $email_template)) {
                $success = 'ثبت‌نام با موفقیت انجام شد. لطفاً ایمیل خود را برای فعال‌سازی حساب بررسی کنید.';
                
                // ثبت لاگ
                log_action('register', sprintf('کاربر جدید "%s" با نام کاربری "%s" ثبت‌نام کرد', $full_name, $username));
                
                // پاک کردن داده‌های فرم
                $_POST = [];
            } else {
                $errors['email'] = 'خطا در ارسال ایمیل فعال‌سازی';
            }
            
        } catch (PDOException $e) {
            error_log($e->getMessage());
            $errors['system'] = 'خطا در ثبت اطلاعات. لطفاً دوباره تلاش کنید.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ثبت‌نام در <?php echo SITE_NAME; ?></title>
    <link rel="stylesheet" href="assets/css/bootstrap.rtl.min.css">
    <link rel="stylesheet" href="assets/css/auth.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
</head>
<body class="bg-light">
    <div class="container">
        <div class="row justify-content-center py-5">
            <div class="col-md-8 col-lg-6">
                <div class="text-center mb-4">
                    <a href="index.php">
                        <img src="assets/images/logo.png" alt="<?php echo SITE_NAME; ?>" height="60">
                    </a>
                </div>
                
                <div class="card shadow-lg border-0">
                    <div class="card-header bg-primary text-white text-center py-4">
                        <h4 class="mb-0">ثبت‌نام در سیستم</h4>
                    </div>
                    <div class="card-body p-4">
                        <?php if (!empty($errors['system'])): ?>
                            <div class="alert alert-danger alert-dismissible fade show">
                                <?php echo $errors['system']; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php endif; ?>

                        <?php if ($success): ?>
                            <div class="alert alert-success alert-dismissible fade show">
                                <?php echo $success; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            </div>
                        <?php else: ?>
                            <form method="POST" class="needs-validation" novalidate autocomplete="off">
                                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                                
                                <!-- نام کاربری -->
                                <div class="form-floating mb-3">
                                    <input type="text" 
                                           class="form-control <?php echo isset($errors['username']) ? 'is-invalid' : ''; ?>" 
                                           id="username" 
                                           name="username" 
                                           placeholder="نام کاربری"
                                           value="<?php echo htmlspecialchars($_POST['username'] ?? ''); ?>"
                                           pattern="[a-zA-Z0-9_]+"
                                           minlength="4"
                                           maxlength="50"
                                           required>
                                    <label for="username" class="required">
                                        <i class="bi bi-person"></i>
                                        نام کاربری
                                    </label>
                                    <?php if (isset($errors['username'])): ?>
                                        <div class="invalid-feedback"><?php echo $errors['username']; ?></div>
                                    <?php endif; ?>
                                    <div class="form-text">حداقل 4 حرف، فقط شامل حروف انگلیسی، اعداد و _</div>
                                </div>

                                <!-- رمز عبور -->
                                <div class="form-floating mb-3">
                                    <div class="password-wrapper">
                                        <input type="password" 
                                               class="form-control <?php echo isset($errors['password']) ? 'is-invalid' : ''; ?>" 
                                               id="password" 
                                               name="password" 
                                               placeholder="رمز عبور"
                                               minlength="8"
                                               required>
                                        <button type="button" 
                                                class="btn btn-link password-toggle" 
                                                onclick="togglePassword('password')"
                                                tabindex="-1">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                        <label for="password" class="required">
                                            <i class="bi bi-key"></i>
                                            رمز عبور
                                        </label>
                                        <?php if (isset($errors['password'])): ?>
                                            <div class="invalid-feedback"><?php echo $errors['password']; ?></div>
                                        <?php endif; ?>
                                        <div class="form-text">حداقل 8 کاراکتر شامل حروف بزرگ، کوچک و اعداد</div>
                                    </div>
                                </div>

                                <!-- تکرار رمز عبور -->
                                <div class="form-floating mb-3">
                                    <div class="password-wrapper">
                                        <input type="password" 
                                               class="form-control <?php echo isset($errors['confirm_password']) ? 'is-invalid' : ''; ?>" 
                                               id="confirm_password" 
                                               name="confirm_password" 
                                               placeholder="تکرار رمز عبور"
                                               required>
                                        <button type="button" 
                                                class="btn btn-link password-toggle" 
                                                onclick="togglePassword('confirm_password')"
                                                tabindex="-1">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                        <label for="confirm_password" class="required">
                                            <i class="bi bi-key-fill"></i>
                                            تکرار رمز عبور
                                        </label>
                                        <?php if (isset($errors['confirm_password'])): ?>
                                            <div class="invalid-feedback"><?php echo $errors['confirm_password']; ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- نام و نام خانوادگی -->
                                <div class="form-floating mb-3">
                                    <input type="text" 
                                           class="form-control <?php echo isset($errors['full_name']) ? 'is-invalid' : ''; ?>" 
                                           id="full_name" 
                                           name="full_name" 
                                           placeholder="نام و نام خانوادگی"
                                           value="<?php echo htmlspecialchars($_POST['full_name'] ?? ''); ?>"
                                           maxlength="100"
                                           required>
                                    <label for="full_name" class="required">
                                        <i class="bi bi-person-vcard"></i>
                                        نام و نام خانوادگی
                                    </label>
                                    <?php if (isset($errors['full_name'])): ?>
                                        <div class="invalid-feedback"><?php echo $errors['full_name']; ?></div>
                                    <?php endif; ?>
                                </div>
                                <!-- ایمیل -->
                                <div class="form-floating mb-3">
                                    <input type="email" 
                                           class="form-control <?php echo isset($errors['email']) ? 'is-invalid' : ''; ?>" 
                                           id="email" 
                                           name="email" 
                                           placeholder="ایمیل"
                                           value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                                           required>
                                    <label for="email" class="required">
                                        <i class="bi bi-envelope"></i>
                                        ایمیل
                                    </label>
                                    <?php if (isset($errors['email'])): ?>
                                        <div class="invalid-feedback"><?php echo $errors['email']; ?></div>
                                    <?php endif; ?>
                                </div>

                                <!-- موبایل -->
                                <div class="form-floating mb-4">
                                    <input type="tel" 
                                           class="form-control <?php echo isset($errors['mobile']) ? 'is-invalid' : ''; ?>" 
                                           id="mobile" 
                                           name="mobile" 
                                           placeholder="شماره موبایل"
                                           value="<?php echo htmlspecialchars($_POST['mobile'] ?? ''); ?>"
                                           pattern="09[0-9]{9}">
                                    <label for="mobile">
                                        <i class="bi bi-phone"></i>
                                        شماره موبایل
                                    </label>
                                    <?php if (isset($errors['mobile'])): ?>
                                        <div class="invalid-feedback"><?php echo $errors['mobile']; ?></div>
                                    <?php endif; ?>
                                    <div class="form-text">مثال: 09123456789</div>
                                </div>

                                <button type="submit" class="btn btn-primary w-100 mb-3">
                                    <i class="bi bi-person-plus"></i>
                                    ثبت‌نام
                                </button>

                                <div class="text-center">
                                    <span>قبلاً ثبت‌نام کرده‌اید؟</span>
                                    <a href="login.php" class="text-decoration-none">وارد شوید</a>
                                </div>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="text-center mt-4">
                    <a href="index.php" class="text-decoration-none">
                        <i class="bi bi-house"></i>
                        بازگشت به صفحه اصلی
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- فایل‌های جاوااسکریپت -->
    <script src="assets/js/bootstrap.bundle.min.js"></script>
    <script>
        // اعتبارسنجی فرم
        (function () {
            'use strict';
            var forms = document.querySelectorAll('.needs-validation');
            Array.from(forms).forEach(function (form) {
                form.addEventListener('submit', function (event) {
                    if (!form.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        })();

        // نمایش/مخفی کردن رمز عبور
        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            const icon = input.parentElement.querySelector('.password-toggle i');
            
            if (input.type === 'password') {
                input.type = 'text';
                icon.classList.replace('bi-eye', 'bi-eye-slash');
            } else {
                input.type = 'password';
                icon.classList.replace('bi-eye-slash', 'bi-eye');
            }
        }

        // اعتبارسنجی نام کاربری
        document.getElementById('username').addEventListener('input', function() {
            const pattern = /^[a-zA-Z0-9_]+$/;
            if (!pattern.test(this.value)) {
                this.setCustomValidity('نام کاربری فقط می‌تواند شامل حروف انگلیسی، اعداد و _ باشد');
            } else {
                this.setCustomValidity('');
            }
        });

        // اعتبارسنجی رمز عبور
        document.getElementById('password').addEventListener('input', function() {
            const pattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/;
            if (!pattern.test(this.value)) {
                this.setCustomValidity('رمز عبور باید شامل حروف بزرگ، کوچک و اعداد باشد');
            } else {
                this.setCustomValidity('');
            }
        });

        // تایید رمز عبور
        document.getElementById('confirm_password').addEventListener('input', function() {
            const password = document.getElementById('password').value;
            if (this.value !== password) {
                this.setCustomValidity('رمز عبور و تکرار آن یکسان نیستند');
            } else {
                this.setCustomValidity('');
            }
        });

        // فرمت کردن شماره موبایل
        document.getElementById('mobile').addEventListener('input', function() {
            this.value = this.value.replace(/[^0-9]/g, '').substring(0, 11);
        });
    </script>

    <?php if (defined('ENABLE_CAPTCHA') && ENABLE_CAPTCHA): ?>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <?php endif; ?>
    <style>
    /* استایل‌های اضافی */
    .required::after {
        content: '*';
        color: red;
        margin-right: 4px;
    }
    
    .password-wrapper {
        position: relative;
    }
    
    .password-toggle {
        position: absolute;
        left: 0;
        top: 50%;
        transform: translateY(-50%);
        background: none;
        border: none;
        color: #6c757d;
        padding: 0.375rem 0.75rem;
    }
    
    .password-toggle:hover {
        color: #0d6efd;
    }
    
    .form-floating > label {
        right: 0;
        left: auto;
        padding-right: 1rem;
        transform-origin: 100% 0;
    }
    
    .form-floating > .form-control:focus ~ label,
    .form-floating > .form-control:not(:placeholder-shown) ~ label {
        transform: scale(.85) translateY(-.5rem) translateX(.15rem);
    }
    
    .form-floating > .form-control-plaintext ~ label,
    .form-floating > .form-select ~ label {
        transform: scale(.85) translateY(-.5rem) translateX(.15rem);
    }
    
    .card {
        border-radius: 1rem;
    }
    
    .card-header:first-child {
        border-radius: 1rem 1rem 0 0;
    }
    
    .btn i {
        margin-left: 0.5rem;
        vertical-align: -0.125em;
    }
    
    .alert {
        border: none;
        border-radius: 0.5rem;
    }
    
    .alert-dismissible .btn-close {
        left: 1rem;
        right: auto;
    }
    
    @media (max-width: 576px) {
        .container {
            padding: 0.5rem;
        }
        
        .card-body {
            padding: 1rem;
        }
        
        h4 {
            font-size: 1.2rem;
        }
    }
</style>
</body>
</html>